#include <stdio.h>
#include "gfx.h"

static void
_on_btn_clicked (void *data, Evas_Object *obj, void *event_info)
{
  (void) obj;
  (void) event_info;
  Evas_Object *entry = (Evas_Object *) data;

  const char *text = gfx_entry_get_text (entry);
  printf ("Button clicked! Input text: %s\n", text ? text : "(empty)");
}

static void
_on_slider_changed (void *data, Evas_Object *obj, void *event_info)
{
  (void) data;
  (void) event_info;

  double val = gfx_slider_get_value (obj);
  printf ("Slider value changed: %.2f\n", val);
}

static void
_on_check_changed (void *data, Evas_Object *obj, void *event_info)
{
  (void) data;
  (void) event_info;

  Eina_Bool state = gfx_check_get_state (obj);
  printf ("Checkbox state: %s\n", state ? "Checked" : "Unchecked");
}

static void
_on_window_del (void *data, Evas_Object *obj, void *event_info)
{
  (void) data;
  (void) obj;
  (void) event_info;

  gfx_exit ();
}

int
main (int argc, char **argv)
{
  Evas_Object *win;
  Evas_Object *scroller;
  Evas_Object *main_box;
  Evas_Object *frame;
  Evas_Object *grid;
  Evas_Object *table;
  Evas_Object *lbl_title;
  Evas_Object *entry;
  Evas_Object *btn;
  Evas_Object *chk;
  Evas_Object *rad1, *rad2;
  Evas_Object *slider;
  Evas_Object *spinner;
  Evas_Object *progress;
  Evas_Object *clock_widget;
  Evas_Object *calendar;
  Evas_Object *separator;
  Evas_Object *icon;
  Evas_Object *bubble;
  Evas_Object *popup;
  Evas *canvas;
  Evas_Object *rect;
  Evas_Object *raw_txt;

  /* 1. Initialize Library */
  gfx_set_policy (ELM_POLICY_QUIT, ELM_POLICY_QUIT_LAST_WINDOW_CLOSED);
  if (gfx_init (argc, argv) < 0)
    {
      fprintf (stderr, "Error: Library initialization failed!\n");
      return -1;
    }

  /* 2. Window Creation and Configuration */
  win = gfx_object_add_feature_window ("main_window", "GFX Comprehensive Test");
  gfx_window_set_autodel (win, EINA_TRUE);
  gfx_window_set_minsize (win, 500, 600);
  gfx_window_set_center (win, EINA_TRUE, EINA_TRUE);
  gfx_object_add_smartcallback (win, "delete,request", _on_window_del, NULL);

  /* 3. Scroller Area */
  scroller = gfx_object_add_scroller (win);
  gfx_scroller_set_policy (scroller, ELM_SCROLLER_POLICY_AUTO, ELM_SCROLLER_POLICY_AUTO);
  evas_object_size_hint_weight_set (scroller, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
  evas_object_size_hint_align_set (scroller, EVAS_HINT_FILL, EVAS_HINT_FILL);
  gfx_window_ratio_scale (win, scroller);
  gfx_object_show (scroller);

  /* 4. Main Vertical Box Layout */
  main_box = gfx_object_add_box (win);
  gfx_box_set_horizontal (main_box, EINA_FALSE);
  gfx_box_set_homogeneous (main_box, EINA_FALSE);
  gfx_box_set_padding (main_box, 10, 15);
  evas_object_size_hint_weight_set (main_box, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
  evas_object_size_hint_align_set (main_box, EVAS_HINT_FILL, EVAS_HINT_FILL);
  gfx_object_set_content (scroller, main_box);
  gfx_object_show (main_box);

  /* 5. Title Label */
  lbl_title = gfx_object_add_label (win);
  gfx_object_set_text (lbl_title, "<font_size=18><b>GFX All Components Test Screen</b></font_size>");
  gfx_box_pack_start (main_box, lbl_title);
  gfx_object_show (lbl_title);

  /* 6. Frame Component & Grid Layout Inside */
  frame = gfx_object_add_frame (win);
  gfx_object_set_text (frame, "Form Controls (Grid)");
  gfx_frame_set_collapsible (frame, EINA_TRUE);
  gfx_box_pack_end (main_box, frame);
  gfx_object_show (frame);

  grid = gfx_object_add_grid (win);
  gfx_grid_set_size (grid, 100, 100);
  evas_object_size_hint_min_set (grid, 300, 200);
  gfx_object_set_content (frame, grid);
  gfx_object_show (grid);

  /* Entry (Text Input) */
  entry = gfx_object_add_entry (win);
  gfx_entry_set_text (entry, "Sample Text");
  gfx_entry_set_singleline (entry, EINA_TRUE);
  gfx_grid_add_pack (grid, entry, 5, 5, 90, 20);
  gfx_object_show (entry);

  /* Button */
  btn = gfx_object_add_button (win);
  gfx_object_set_text (btn, "Print Text to Console");
  gfx_object_add_smartcallback (btn, "clicked", _on_btn_clicked, entry);
  gfx_grid_add_pack (grid, btn, 5, 30, 90, 20);
  gfx_object_show (btn);

  /* Checkbutton */
  chk = gfx_object_add_checkbutton (win);
  gfx_object_set_text (chk, "Option Checkbox");
  gfx_check_set_state (chk, EINA_TRUE);
  gfx_object_add_smartcallback (chk, "changed", _on_check_changed, NULL);
  gfx_grid_add_pack (grid, chk, 5, 55, 40, 20);
  gfx_object_show (chk);

  /* Radiobuttons */
  rad1 = gfx_object_add_radiobutton (win);
  gfx_object_set_text (rad1, "Option 1");
  gfx_radio_set_value (rad1, 1);
  gfx_grid_add_pack (grid, rad1, 50, 55, 20, 20);
  gfx_object_show (rad1);

  rad2 = gfx_object_add_radiobutton (win);
  gfx_object_set_text (rad2, "Option 2");
  gfx_radio_set_value (rad2, 2);
  gfx_grid_add_pack (grid, rad2, 70, 55, 20, 20);
  gfx_object_show (rad2);

  /* Slider */
  slider = gfx_object_add_slider (win);
  gfx_slider_set_value (slider, 45.0);
  gfx_object_add_smartcallback (slider, "changed", _on_slider_changed, NULL);
  gfx_grid_add_pack (grid, slider, 5, 80, 90, 15);
  gfx_object_show (slider);

  /* 7. Separator */
  separator = gfx_object_add_separator (win);
  gfx_box_pack_end (main_box, separator);
  gfx_object_show (separator);

  /* 8. Table Layout and Numeric Components */
  table = gfx_object_add_table (win);
  gfx_table_set_homogeneous (table, EINA_TRUE);
  gfx_table_set_padding (table, 5, 5);
  gfx_box_pack_end (main_box, table);
  gfx_object_show (table);

  /* Spinner */
  spinner = gfx_object_add_spinner (win);
  gfx_table_pack (table, spinner, 0, 0, 1, 1);
  gfx_object_show (spinner);

  /* Progressbar */
  progress = gfx_object_add_progressbar (win);
  gfx_table_pack (table, progress, 1, 0, 1, 1);
  gfx_object_show (progress);

  /* System Icon */
  icon = gfx_object_add_icon (win);
  gfx_icon_set_standard (icon, "home");
  gfx_table_pack (table, icon, 0, 1, 1, 1);
  gfx_object_show (icon);

  /* Clock Widget */
  clock_widget = gfx_object_add_clock (win);
  gfx_table_pack (table, clock_widget, 1, 1, 1, 1);
  gfx_object_show (clock_widget);

  /* 9. Calendar */
  calendar = gfx_object_add_calendar (win);
  gfx_box_pack_end (main_box, calendar);
  gfx_object_show (calendar);

  /* 10. Bubble Component */
  bubble = gfx_object_add_bubble (win);
  gfx_object_set_text (bubble, "Information");
  gfx_object_set_parttext (bubble, "info", "System Notification");
  gfx_box_pack_end (main_box, bubble);
  gfx_object_show (bubble);

  /* 11. Direct EVAS Drawing Operations (grassfx_evas.c Test) */
  canvas = gfx_object_get_evas (win);
  if (canvas)
    {
      /* Rectangle Object */
      rect = gfx_object_add_rectangle (canvas);
      gfx_object_set_color (rect, 100, 150, 250, 255);
      evas_object_size_hint_min_set (rect, 200, 40);
      gfx_box_pack_end (main_box, rect);
      gfx_object_show (rect);

      /* Raw EVAS Text Object */
      raw_txt = gfx_object_add_text (canvas);
      gfx_object_set_rawtext (raw_txt, "EVAS Direct Canvas Text");
      gfx_object_set_color (raw_txt, 255, 255, 255, 255);
      gfx_object_move (raw_txt, 20, 20);
      gfx_object_show (raw_txt);
    }

  /* 12. Popup Component */
  popup = gfx_object_add_popup (win);
  gfx_object_set_text (popup, "GFX UI Components Successfully Loaded!");
  gfx_object_show (popup);

  /* 13. Display Window & Set Size */
  gfx_object_resize (win, 600, 700);
  gfx_object_show (win);

  /* 14. Main Event Loop */
  gfx_run ();

  /* 15. Shutdown and Cleanup */
  gfx_shutdown ();

  return 0;
}
