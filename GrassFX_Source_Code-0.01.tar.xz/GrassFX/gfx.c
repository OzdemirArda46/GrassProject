#include <Elementary.h>
#include <stdio.h>
#include "gfx.h"

/* General Functions - Start */

    int 
    gfx_init (int argc, char **argv)
    {
        return elm_init (argc, argv);
    }

    void 
    gfx_run (void)
    {
        elm_run ();
    }
    
    void 
    gfx_exit (void)
    {
        elm_exit ();
    }
    
    void 
    gfx_shutdown (void)
    {
        elm_shutdown ();
    }
        
/* General Functions - End */

/* Window Functions - Start */

    Evas_Object *
    gfx_object_add_feature_window (const char *name, const char *title)
    {
        if (!name || !title)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_win_util_standard_add (name, title);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_standard_window (Evas_Object *parent, const char *name, Elm_Win_Type type)
    {
        if (!name)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_win_add (parent, name, type);
        
        return object;
    }
        
    int 
    gfx_window_set_title (Evas_Object *object, const char *title)
    {
        if (!object || !title)
        {
            return -1;
        }
        
        elm_win_title_set (object, title);
        
        return 0;
    }
        
    int 
    gfx_window_set_autodel (Evas_Object *object, Eina_Bool autodel)
    {
        if (!object)
        {
            return -1;
        }
        
        elm_win_autodel_set (object, autodel);
        
        return 0;
    }
        
    int 
    gfx_window_set_center (Evas_Object *object, Eina_Bool h, Eina_Bool v)
    {
        if (!object)
        {
            return -1;
        }
        
        elm_win_center (object, h, v);
        
        return 0;
    }
        
    int 
    gfx_window_set_minsize (Evas_Object *object, int w, int h)
    {
        if (!object)
        {
            return -1;
        }
        
        elm_win_size_base_set (object, w, h);
        
        return 0;
    }
        
    int 
    gfx_window_set_fullscreen (Evas_Object *object, Eina_Bool full)
    {
        if (!object)
        {
            return -1;
        }
        
        elm_win_fullscreen_set (object, full);
        
        return 0;
    }
        
    int 
    gfx_window_set_active (Evas_Object *object)
    {
        if (!object)
        {
            return -1;
        }
        
        elm_win_activate (object);
        
        return 0;
    }
        
    int 
    gfx_window_set_iconified (Evas_Object *object, Eina_Bool iconified)
    {
        if (!object)
        {
            return -1;
        }
        
        elm_win_iconified_set (object, iconified);
        
        return 0;
    }
        
    int 
    gfx_window_set_sticky (Evas_Object *object, Eina_Bool sticky)
    {
        if (!object)
        {
            return -1;
        }
        
        elm_win_sticky_set (object, sticky);
        
        return 0;
    }
    
    int 
    gfx_window_ratio_scale (Evas_Object *object, Evas_Object *subobject)
    {
        if (!object || !subobject)
        {
            return -1;
        }
        
        elm_win_resize_object_add (object, subobject);
        
        return 0;
    }

/* Window Functions - End */

/* Widget Creation Functions - Start */

    Evas_Object *
    gfx_object_add_button (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_button_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_checkbutton (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_check_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_radiobutton (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_radio_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_entry (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_entry_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_slider (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_slider_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_spinner (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_spinner_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_combobox (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_combobox_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_label (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_label_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_icon (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_icon_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_image (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_image_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_progressbar (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_progressbar_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_bubble (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_bubble_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_clock (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_clock_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_calendar (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_calendar_add (parent);
        
        return object;
    }
        
    Evas_Object *
    gfx_object_add_separator (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_separator_add (parent);
        
        return object;
    }

/* Widget Creation Functions - End */

/* Box Functions - Start */
    
    Evas_Object *
    gfx_object_add_box (Evas_Object *parent)
    {
        if (!parent)
        {
            return NULL;
        }
        
        Evas_Object *object = elm_box_add (parent);
        
        return object;
    }
        
    void 
    gfx_box_set_horizontal (Evas_Object *object, Eina_Bool horizontal)
    {
        elm_box_horizontal_set (object, horizontal);
    }
            
    Eina_Bool 
    gfx_box_get_horizontal (const Evas_Object *object)
    {
        if (!object)
        {
            return EINA_FALSE;
        }
        
        return elm_box_horizontal_get (object);
    }
        
    void 
    gfx_box_pack_start (Evas_Object *object, Evas_Object *child)
    {
        elm_box_pack_start (object, child);
    }
            
    void 
    gfx_box_pack_end (Evas_Object *object, Evas_Object *child)
    {
        elm_box_pack_end (object, child);
    }
            
    void 
    gfx_box_pack_before (Evas_Object *object, Evas_Object *child, Evas_Object *before)
    {
        elm_box_pack_before (object, child, before);
    }
            
    void 
    gfx_box_pack_after (Evas_Object *object, Evas_Object *child, Evas_Object *after)
    {
        elm_box_pack_after (object, child, after);
    }
        
    void 
    gfx_box_unpack (Evas_Object *object, Evas_Object *child)
    {
        elm_box_unpack (object, child);
    }
            
    void 
    gfx_box_unpack_all (Evas_Object *object)
    {
        elm_box_unpack_all (object);
    }
        
    void 
    gfx_box_set_homogeneous (Evas_Object *object, Eina_Bool homogeneous)
    {
        elm_box_homogeneous_set (object, homogeneous);
    }
            
    Eina_Bool 
    gfx_box_get_homogeneous (Evas_Object *object)
    {
        if (!object)
        {
            return EINA_FALSE;
        }
        
        return elm_box_homogeneous_get (object);
    }
        
    void 
    gfx_box_set_padding (Evas_Object *object, Evas_Coord horizontal, Evas_Coord vertical)
    {
        elm_box_padding_set (object, horizontal, vertical);
    }
            
    void 
    gfx_box_get_padding (Evas_Object *object, Evas_Coord *horizontal, Evas_Coord *vertical)
    {
        elm_box_padding_get (object, horizontal, vertical);
    }
        
    void 
    gfx_box_set_align (Evas_Object *object, double horizontal, double vertical)
    {
        elm_box_align_set (object, horizontal, vertical);
    }
            
    void 
    gfx_box_get_align (Evas_Object *object, double *horizontal, double *vertical)
    {
        elm_box_align_get (object, horizontal, vertical);
    }
        
    Eina_List *
    gfx_box_get_children (const Evas_Object *object)
    {
        Eina_List *list = elm_box_children_get (object);
        
        return list;
    }

/* Box Functions - End */