GrassFX Library

This project is a wrapper graphics library prepared to use the EFL (Enlightenment Foundation Libraries) based Elementary library more easily.

File Structure:
- gfx.c: The source code file containing the main bodies of the functions.
- gfx.h: The header file containing the prototypes of the functions.
- main.c: The sample test program demonstrating how to use the library.
- Linking.txt: Contains the sample command required to compile and run the project.

Usage and Compilation Instructions:
If you want to use this library or the sample test, you can compile it by pasting the command inside the "Linking.txt" file into your terminal.

NOTE!!!: If you are going to run the compilation command, make sure you execute it in the exact directory where gfx.h, gfx.c, and main.c are located; otherwise, the files will not be found and the code will fail to compile.
