#ifndef GFX_H
#define GFX_H

#include <Elementary.h>
#include <stdio.h>

/* General Functions - Start */

    int gfx_init (int argc, char **argv);
    void gfx_run (void);
    void gfx_exit (void);
    void gfx_shutdown (void);

/* General Functions - End */

/* Window Functions - Start */

    Evas_Object *gfx_object_add_feature_window (const char *name, const char *title);
    Evas_Object *gfx_object_add_standard_window (Evas_Object *parent, const char *name, Elm_Win_Type type);
    
    int gfx_window_set_title (Evas_Object *object, const char *title);
    int gfx_window_set_autodel (Evas_Object *object, Eina_Bool autodel);
    
    int gfx_window_set_center (Evas_Object *object, Eina_Bool h, Eina_Bool v);
    int gfx_window_set_minsize (Evas_Object *object, int w, int h);
    
    int gfx_window_set_fullscreen (Evas_Object *object, Eina_Bool full);
    int gfx_window_set_active (Evas_Object *object);
    int gfx_window_set_iconified (Evas_Object *object, Eina_Bool iconified);
    int gfx_window_set_sticky (Evas_Object *object, Eina_Bool sticky);
    
    int gfx_window_ratio_scale (Evas_Object *object, Evas_Object *subobject);

/* Window Functions - End */

/* Widget Creation Functions - Start */

    Evas_Object *gfx_object_add_button (Evas_Object *parent);
    Evas_Object *gfx_object_add_checkbutton (Evas_Object *parent);
    Evas_Object *gfx_object_add_radiobutton (Evas_Object *parent);
    Evas_Object *gfx_object_add_entry (Evas_Object *parent);
    Evas_Object *gfx_object_add_slider (Evas_Object *parent);
    Evas_Object *gfx_object_add_spinner (Evas_Object *parent);
    Evas_Object *gfx_object_add_combobox (Evas_Object *parent);
    
    Evas_Object *gfx_object_add_label (Evas_Object *parent);
    Evas_Object *gfx_object_add_icon (Evas_Object *parent);
    Evas_Object *gfx_object_add_image (Evas_Object *parent);
    Evas_Object *gfx_object_add_progressbar (Evas_Object *parent);
    Evas_Object *gfx_object_add_bubble (Evas_Object *parent);
    Evas_Object *gfx_object_add_clock (Evas_Object *parent);
    Evas_Object *gfx_object_add_calendar (Evas_Object *parent);
    Evas_Object *gfx_object_add_separator (Evas_Object *parent);
    
/* Widget Creation Functions - End */

/* Box Functions - Start */

    Evas_Object *gfx_object_add_box (Evas_Object *parent);
    
    void gfx_box_set_horizontal (Evas_Object *object, Eina_Bool horizontal);
    Eina_Bool gfx_box_get_horizontal (const Evas_Object *object);
    
    void gfx_box_pack_start (Evas_Object *object, Evas_Object *child);
    void gfx_box_pack_end (Evas_Object *object, Evas_Object *child);
    void gfx_box_pack_before (Evas_Object *object, Evas_Object *child, Evas_Object *before);
    void gfx_box_pack_after (Evas_Object *object, Evas_Object *child, Evas_Object *after);

    void gfx_box_unpack (Evas_Object *object, Evas_Object *child);
    void gfx_box_unpack_all (Evas_Object *object);

    void gfx_box_set_homogeneous (Evas_Object *object, Eina_Bool homogeneous);
    Eina_Bool gfx_box_get_homogeneous (Evas_Object *object);

    void gfx_box_set_padding (Evas_Object *object, Evas_Coord horizontal, Evas_Coord vertical);
    void gfx_box_get_padding (Evas_Object *object, Evas_Coord *horizontal, Evas_Coord *vertical);

    void gfx_box_set_align (Evas_Object *object, double horizontal, double vertical);
    void gfx_box_get_align (Evas_Object *object, double *horizontal, double *vertical);

    Eina_List *gfx_box_get_children (const Evas_Object *object);
    
/* Box Functions - End */

#endif