#include <Elementary.h>
#include "gfx.h"
#include <stdio.h>

int 
main (int argc, char **argv)
{
    gfx_init (argc, argv);

    Evas_Object *win = gfx_object_add_feature_window ("test", "EFL Comprehensive Test Window");
    gfx_window_set_title (win, "EFL All Functions Test");
    gfx_window_set_autodel (win, EINA_TRUE);
    
    evas_object_resize (win, 1000, 800);
    
    gfx_window_set_center (win, EINA_TRUE, EINA_TRUE);
    gfx_window_set_active (win);

    Evas_Object *box = gfx_object_add_box (win);
    gfx_box_set_horizontal (box, EINA_FALSE);
    
    evas_object_size_hint_weight_set (box, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
    evas_object_size_hint_align_set (box, EVAS_HINT_FILL, EVAS_HINT_FILL);
    
    gfx_window_ratio_scale (win, box);
    evas_object_show (box);

    Eina_Bool is_horiz = gfx_box_get_horizontal (box);
    printf ("Is box horizontal?: %d\n", is_horiz);

    gfx_box_set_homogeneous (box, EINA_FALSE);
    Eina_Bool is_homog = gfx_box_get_homogeneous (box);
    printf ("Is box homogeneous?: %d\n", is_homog);

    gfx_box_set_padding (box, 10, 10);
    Evas_Coord pad_h, pad_v;
    gfx_box_get_padding (box, &pad_h, &pad_v);
    printf ("Padding values -> Horizontal: %d, Vertical: %d\n", pad_h, pad_v);

    gfx_box_set_align (box, 0.5, 0.5);
    double align_h, align_v;
    gfx_box_get_align (box, &align_h, &align_v);
    printf ("Alignment values -> Horizontal: %f, Vertical: %f\n", align_h, align_v);

    Evas_Object *lbl = gfx_object_add_label (win);
    elm_object_text_set (lbl, "This is a label test.");
    evas_object_size_hint_weight_set (lbl, EVAS_HINT_EXPAND, 0.0);
    evas_object_size_hint_align_set (lbl, EVAS_HINT_FILL, 0.5);
    evas_object_show (lbl);
    gfx_box_pack_start (box, lbl);

    Evas_Object *btn = gfx_object_add_button (win);
    elm_object_text_set (btn, "Test Button");
    evas_object_size_hint_weight_set (btn, EVAS_HINT_EXPAND, 0.0);
    evas_object_size_hint_align_set (btn, EVAS_HINT_FILL, 0.5);
    evas_object_show (btn);
    gfx_box_pack_start (box, btn);

    Evas_Object *chk = gfx_object_add_checkbutton (win);
    elm_object_text_set (chk, "Checkbutton Option");
    evas_object_size_hint_weight_set (chk, EVAS_HINT_EXPAND, 0.0);
    evas_object_size_hint_align_set (chk, EVAS_HINT_FILL, 0.5);
    evas_object_show (chk);
    gfx_box_pack_start (box, chk);

    Evas_Object *radio = gfx_object_add_radiobutton (win);
    elm_object_text_set (radio, "Radio Button");
    evas_object_size_hint_weight_set (radio, EVAS_HINT_EXPAND, 0.0);
    evas_object_size_hint_align_set (radio, EVAS_HINT_FILL, 0.5);
    evas_object_show (radio);
    gfx_box_pack_start (box, radio);

    Evas_Object *entry = gfx_object_add_entry (win);
    elm_object_text_set (entry, "Text input area...");
    evas_object_size_hint_weight_set (entry, EVAS_HINT_EXPAND, 0.0);
    evas_object_size_hint_align_set (entry, EVAS_HINT_FILL, 0.5);
    evas_object_show (entry);
    gfx_box_pack_start (box, entry);

    Evas_Object *slider = gfx_object_add_slider (win);
    evas_object_size_hint_weight_set (slider, EVAS_HINT_EXPAND, 0.0);
    evas_object_size_hint_align_set (slider, EVAS_HINT_FILL, 0.5);
    evas_object_show (slider);
    gfx_box_pack_start (box, slider);

    Evas_Object *spinner = gfx_object_add_spinner (win);
    evas_object_size_hint_weight_set (spinner, EVAS_HINT_EXPAND, 0.0);
    evas_object_size_hint_align_set (spinner, EVAS_HINT_FILL, 0.5);
    evas_object_show (spinner);
    gfx_box_pack_start (box, spinner);

    Evas_Object *pbar = gfx_object_add_progressbar (win);
    elm_progressbar_value_set (pbar, 0.65);
    evas_object_size_hint_weight_set (pbar, EVAS_HINT_EXPAND, 0.0);
    evas_object_size_hint_align_set (pbar, EVAS_HINT_FILL, 0.5);
    evas_object_show (pbar);
    gfx_box_pack_start (box, pbar);

    Evas_Object *clock = gfx_object_add_clock (win);
    evas_object_size_hint_weight_set (clock, EVAS_HINT_EXPAND, 0.0);
    evas_object_size_hint_align_set (clock, EVAS_HINT_FILL, 0.5);
    evas_object_show (clock);
    gfx_box_pack_start (box, clock);

    Evas_Object *cal = gfx_object_add_calendar (win);
    evas_object_size_hint_weight_set (cal, EVAS_HINT_EXPAND, 0.0);
    evas_object_size_hint_align_set (cal, EVAS_HINT_FILL, 0.5);
    evas_object_show (cal);
    gfx_box_pack_start (box, cal);

    Evas_Object *sep = gfx_object_add_separator (win);
    evas_object_size_hint_weight_set (sep, EVAS_HINT_EXPAND, 0.0);
    evas_object_size_hint_align_set (sep, EVAS_HINT_FILL, 0.5);
    evas_object_show (sep);
    gfx_box_pack_start (box, sep);

    Eina_List *children = gfx_box_get_children (box);
    printf ("Total number of children in box: %d\n", eina_list_count (children));

    evas_object_show (win);

    gfx_run ();
    gfx_shutdown ();

    return 0;
}