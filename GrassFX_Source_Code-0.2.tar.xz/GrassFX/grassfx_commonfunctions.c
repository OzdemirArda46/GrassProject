#include <Elementary.h>
#include <Ecore.h>
#include <stdio.h>
#include "grassfx.h"

/* General Functions - Start */

int
gfx_init(int argc, char **argv)
{
	int ret = elm_init(argc, argv);
	ecore_init();
	return ret;
}

int
gfx_run(void)
{
	elm_run();
	return 0;
}

int
gfx_exit(void)
{
	ecore_main_loop_quit();
	elm_exit();
	return 0;
}

int
gfx_shutdown(void)
{
	int ret = elm_shutdown();
	ecore_shutdown();
	return ret;
}

/* General Functions - End */
