#ifndef GFX_H
#define GFX_H

#include <Elementary.h>

/* General Functions */
int gfx_init (int argc, char **argv);
void gfx_run (void);
void gfx_exit (void);
void gfx_shutdown (void);

/* Window Functions */
Evas_Object *gfx_object_add_feature_window (const char *name, const char *title);
Evas_Object *gfx_object_add_standard_window (Evas_Object *parent, const char *name, Elm_Win_Type type);
int gfx_window_set_title (Evas_Object *object, const char *title);
int gfx_window_set_autodel (Evas_Object *object, Eina_Bool autodel);
int gfx_window_set_center (Evas_Object *object, Eina_Bool h, Eina_Bool v);
int gfx_window_set_minsize (Evas_Object *object, int w, int h);
int gfx_window_set_fullscreen (Evas_Object *object, Eina_Bool full);
int gfx_window_set_active (Evas_Object *object);
int gfx_window_set_iconified (Evas_Object *object, Eina_Bool iconified);
int gfx_window_set_sticky (Evas_Object *object, Eina_Bool sticky);
int gfx_window_ratio_scale (Evas_Object *object, Evas_Object *subobject);

/* Widget Addition Functions */
Evas_Object *gfx_object_add_button (Evas_Object *parent);
Evas_Object *gfx_object_add_checkbutton (Evas_Object *parent);
Evas_Object *gfx_object_add_radiobutton (Evas_Object *parent);
Evas_Object *gfx_object_add_entry (Evas_Object *parent);
Evas_Object *gfx_object_add_slider (Evas_Object *parent);
Evas_Object *gfx_object_add_spinner (Evas_Object *parent);
Evas_Object *gfx_object_add_combobox (Evas_Object *parent);
Evas_Object *gfx_object_add_label (Evas_Object *parent);
Evas_Object *gfx_object_add_icon (Evas_Object *parent);
Evas_Object *gfx_object_add_image (Evas_Object *parent);
Evas_Object *gfx_object_add_progressbar (Evas_Object *parent);
Evas_Object *gfx_object_add_bubble (Evas_Object *parent);
Evas_Object *gfx_object_add_clock (Evas_Object *parent);
Evas_Object *gfx_object_add_calendar (Evas_Object *parent);
Evas_Object *gfx_object_add_separator (Evas_Object *parent);

/* Box Functions */
Evas_Object *gfx_object_add_box (Evas_Object *parent);
void gfx_box_set_horizontal (Evas_Object *object, Eina_Bool horizontal);
Eina_Bool gfx_box_get_horizontal (const Evas_Object *object);
void gfx_box_pack_start (Evas_Object *object, Evas_Object *child);
void gfx_box_pack_end (Evas_Object *object, Evas_Object *child);
void gfx_box_pack_before (Evas_Object *object, Evas_Object *child, Evas_Object *before);
void gfx_box_pack_after (Evas_Object *object, Evas_Object *child, Evas_Object *after);
void gfx_box_unpack (Evas_Object *object, Evas_Object *child);
void gfx_box_unpack_all (Evas_Object *object);
void gfx_box_set_homogeneous (Evas_Object *object, Eina_Bool homogeneous);
Eina_Bool gfx_box_get_homogeneous (Evas_Object *object);
void gfx_box_set_padding (Evas_Object *object, Evas_Coord horizontal, Evas_Coord vertical);
void gfx_box_get_padding (Evas_Object *object, Evas_Coord *horizontal, Evas_Coord *vertical);
void gfx_box_set_align (Evas_Object *object, double horizontal, double vertical);
void gfx_box_get_align (Evas_Object *object, double *horizontal, double *vertical);
Eina_List *gfx_box_get_children (const Evas_Object *object);

/* Grid Functions */
Evas_Object *gfx_object_add_grid (Evas_Object *parent);
void gfx_grid_set_size (Evas_Object *object, int w, int h);
void gfx_grid_get_size (const Evas_Object *object, int *w, int *h);
void gfx_grid_add_pack (Evas_Object *object, Evas_Object *subobject, int x, int y, int w, int h);
void gfx_grid_unpack (Evas_Object *object, Evas_Object *subobject);
void gfx_grid_set_pack (Evas_Object *subobject, Evas_Coord x, Evas_Coord y, Evas_Coord w, Evas_Coord h);
void gfx_grid_get_pack (Evas_Object *subobject, Evas_Coord *x, Evas_Coord *y, Evas_Coord *w, Evas_Coord *h);
Eina_List *gfx_grid_get_children (const Evas_Object *object);
void gfx_grid_clear (Evas_Object *object, Eina_Bool clear);

/* Table Functions */
Evas_Object *gfx_object_add_table (Evas_Object *parent);
void gfx_table_set_align (Evas_Object *object, double horizontal, double vertical);
void gfx_table_get_align (const Evas_Object *object, double *horizontal, double *vertical);
Evas_Object *gfx_table_get_child (const Evas_Object *object, int col, int row);
void gfx_table_clear (Evas_Object *object, Eina_Bool clear);
void gfx_table_set_homogeneous (Evas_Object *object, Eina_Bool homogeneous);
Eina_Bool gfx_table_get_homogeneous (const Evas_Object *object);
void gfx_table_pack (Evas_Object *object, Evas_Object *subobject, int col, int row, int colspan, int rowspan);
void gfx_table_set_pack (Evas_Object *subobject, int col, int row, int colspan, int rowspan);
void gfx_table_get_pack (Evas_Object *subobject, int *col, int *row, int *colspan, int *rowspan);
void gfx_table_set_padding (Evas_Object *object, Evas_Coord horizontal, Evas_Coord vertical);
void gfx_table_get_padding (Evas_Object *object, Evas_Coord *horizontal, Evas_Coord *vertical);
void gfx_table_unpack (Evas_Object *object, Evas_Object *subobject);

/* Scroller Functions */
Evas_Object *gfx_object_add_scroller (Evas_Object *parent);
void gfx_scroller_set_policy (Evas_Object *object, Elm_Scroller_Policy policy_h, Elm_Scroller_Policy policy_v);
void gfx_scroller_get_policy (const Evas_Object *object, Elm_Scroller_Policy *policy_h, Elm_Scroller_Policy *policy_v);
void gfx_scroller_set_region (Evas_Object *object, Evas_Coord x, Evas_Coord y, Evas_Coord w, Evas_Coord h);
void gfx_scroller_get_region (const Evas_Object *object, Evas_Coord *x, Evas_Coord *y, Evas_Coord *w, Evas_Coord *h);
void gfx_scroller_get_position (const Evas_Object *object, Evas_Coord *x, Evas_Coord *y);
void gfx_scroller_set_pagesize (Evas_Object *object, Evas_Coord w, Evas_Coord h);
void gfx_scroller_get_pagesize (const Evas_Object *object, Evas_Coord *w, Evas_Coord *h);
void gfx_scroller_get_currentpage (const Evas_Object *object, int *hp, int *vp);
void gfx_scroller_show_page (Evas_Object *object, int hp, int vp);
void gfx_scroller_set_bounce (Evas_Object *object, Eina_Bool h_bounce, Eina_Bool v_bounce);
void gfx_scroller_get_bounce (const Evas_Object *object, Eina_Bool *h_bounce, Eina_Bool *v_bounce);

/* Frame Functions */
Evas_Object *gfx_object_add_frame (Evas_Object *parent);
void gfx_frame_set_autocollapse (Evas_Object *object, Eina_Bool autocollapse);
Eina_Bool gfx_frame_get_autocollapse (const Evas_Object *object);
void gfx_frame_set_collapse (Evas_Object *object, Eina_Bool collapse);
Eina_Bool gfx_frame_get_collapse (const Evas_Object *object);
void gfx_frame_set_collapsible (Evas_Object *object, Eina_Bool collapsible);
Eina_Bool gfx_frame_get_collapsible (const Evas_Object *object);

/* Object Management Functions */
void gfx_object_set_text (Evas_Object *object, const char *text);
const char *gfx_object_get_text (const Evas_Object *object);
void gfx_object_set_content (Evas_Object *object, Evas_Object *content);
Evas_Object *gfx_object_get_content (const Evas_Object *object);
void gfx_object_set_parttext (Evas_Object *object, const char *part, const char *text);
void gfx_object_set_partcontent (Evas_Object *object, const char *part, Evas_Object *content);

/* Entry and State Functions */
void gfx_entry_set_text (Evas_Object *object, const char *text);
const char *gfx_entry_get_text (const Evas_Object *object);
void gfx_check_set_state (Evas_Object *object, Eina_Bool checked);
Eina_Bool gfx_check_get_state (const Evas_Object *object);
void gfx_radio_set_value (Evas_Object *object, int value);
int gfx_radio_get_value (const Evas_Object *object);
void gfx_slider_set_value (Evas_Object *object, double value);
double gfx_slider_get_value (const Evas_Object *object);

/* Genlist Functions */
Elm_Object_Item *gfx_genlist_add_item (Evas_Object *object, const Elm_Genlist_Item_Class *itemclass, const void *data, Elm_Object_Item *parent, Elm_Genlist_Item_Type flags, Evas_Smart_Cb function, const void *function_data);
void gfx_genlist_clear (Evas_Object *object);
Elm_Genlist_Item_Class *gfx_genlist_add_itemclass (void);
void gfx_genlist_free_itemclass (Elm_Genlist_Item_Class *itemclass);

#endif
