#include <Elementary.h>
#include <stdio.h>
#include "gfx.h"

/* General Functions - Start */

int
gfx_init (int argc, char **argv)
{
  return elm_init (argc, argv);
}

void
gfx_run (void)
{
  elm_run ();
}

void
gfx_exit (void)
{
  elm_exit ();
}

void
gfx_shutdown (void)
{
  elm_shutdown ();
}

/* General Functions - End */

/* Window Functions - Start */

Evas_Object *
gfx_object_add_feature_window (const char *name, const char *title)
{
  if (!name || !title)
    {
      return NULL;
    }

  Evas_Object *object = elm_win_util_standard_add (name, title);

  return object;
}

Evas_Object *
gfx_object_add_standard_window (Evas_Object *parent, const char *name, Elm_Win_Type type)
{
  if (!name)
    {
      return NULL;
    }

  Evas_Object *object = elm_win_add (parent, name, type);

  return object;
}

int
gfx_window_set_title (Evas_Object *object, const char *title)
{
  if (!object || !title)
    {
      return -1;
    }

  elm_win_title_set (object, title);

  return 0;
}

int
gfx_window_set_autodel (Evas_Object *object, Eina_Bool autodel)
{
  if (!object)
    {
      return -1;
    }

  elm_win_autodel_set (object, autodel);

  return 0;
}

int
gfx_window_set_center (Evas_Object *object, Eina_Bool h, Eina_Bool v)
{
  if (!object)
    {
      return -1;
    }

  elm_win_center (object, h, v);

  return 0;
}

int
gfx_window_set_minsize (Evas_Object *object, int w, int h)
{
  if (!object)
    {
      return -1;
    }

  elm_win_size_base_set (object, w, h);

  return 0;
}

int
gfx_window_set_fullscreen (Evas_Object *object, Eina_Bool full)
{
  if (!object)
    {
      return -1;
    }

  elm_win_fullscreen_set (object, full);

  return 0;
}

int
gfx_window_set_active (Evas_Object *object)
{
  if (!object)
    {
      return -1;
    }

  elm_win_activate (object);

  return 0;
}

int
gfx_window_set_iconified (Evas_Object *object, Eina_Bool iconified)
{
  if (!object)
    {
      return -1;
    }

  elm_win_iconified_set (object, iconified);

  return 0;
}

int
gfx_window_set_sticky (Evas_Object *object, Eina_Bool sticky)
{
  if (!object)
    {
      return -1;
    }

  elm_win_sticky_set (object, sticky);

  return 0;
}

int
gfx_window_ratio_scale (Evas_Object *object, Evas_Object *subobject)
{
  if (!object || !subobject)
    {
      return -1;
    }

  elm_win_resize_object_add (object, subobject);

  return 0;
}

/* Window Functions - End */

/* Widget Addition Functions - Start */

Evas_Object *
gfx_object_add_button (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_button_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_checkbutton (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_check_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_radiobutton (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_radio_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_entry (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_entry_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_slider (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_slider_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_spinner (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_spinner_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_combobox (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_combobox_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_label (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_label_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_icon (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_icon_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_image (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_image_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_progressbar (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_progressbar_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_bubble (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_bubble_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_clock (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_clock_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_calendar (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_calendar_add (parent);

  return object;
}

Evas_Object *
gfx_object_add_separator (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_separator_add (parent);

  return object;
}

/* Widget Addition Functions - End */

/* Box Functions - Start */

Evas_Object *
gfx_object_add_box (Evas_Object *parent)
{
  if (!parent)
    {
      return NULL;
    }

  Evas_Object *object = elm_box_add (parent);

  return object;
}

void
gfx_box_set_horizontal (Evas_Object *object, Eina_Bool horizontal)
{
  elm_box_horizontal_set (object, horizontal);
}

Eina_Bool
gfx_box_get_horizontal (const Evas_Object *object)
{
  if (!object)
    {
      return EINA_FALSE;
    }

  return elm_box_horizontal_get (object);
}

void
gfx_box_pack_start (Evas_Object *object, Evas_Object *child)
{
  elm_box_pack_start (object, child);
}

void
gfx_box_pack_end (Evas_Object *object, Evas_Object *child)
{
  elm_box_pack_end (object, child);
}

void
gfx_box_pack_before (Evas_Object *object, Evas_Object *child, Evas_Object *before)
{
  elm_box_pack_before (object, child, before);
}

void
gfx_box_pack_after (Evas_Object *object, Evas_Object *child, Evas_Object *after)
{
  elm_box_pack_after (object, child, after);
}

void
gfx_box_unpack (Evas_Object *object, Evas_Object *child)
{
  elm_box_unpack (object, child);
}

void
gfx_box_unpack_all (Evas_Object *object)
{
  elm_box_unpack_all (object);
}

void
gfx_box_set_homogeneous (Evas_Object *object, Eina_Bool homogeneous)
{
  elm_box_homogeneous_set (object, homogeneous);
}

Eina_Bool
gfx_box_get_homogeneous (Evas_Object *object)
{
  if (!object)
    {
      return EINA_FALSE;
    }

  return elm_box_homogeneous_get (object);
}

void
gfx_box_set_padding (Evas_Object *object, Evas_Coord horizontal, Evas_Coord vertical)
{
  elm_box_padding_set (object, horizontal, vertical);
}

void
gfx_box_get_padding (Evas_Object *object, Evas_Coord *horizontal, Evas_Coord *vertical)
{
  elm_box_padding_get (object, horizontal, vertical);
}

void
gfx_box_set_align (Evas_Object *object, double horizontal, double vertical)
{
  elm_box_align_set (object, horizontal, vertical);
}

void
gfx_box_get_align (Evas_Object *object, double *horizontal, double *vertical)
{
  elm_box_align_get (object, horizontal, vertical);
}

Eina_List *
gfx_box_get_children (const Evas_Object *object)
{
  Eina_List *list = elm_box_children_get (object);

  return list;
}

/* Box Functions - End */

/* Grid Functions - Start */

Evas_Object *
gfx_object_add_grid (Evas_Object *parent)
{
  Evas_Object *object = elm_grid_add (parent);

  return object;
}

void
gfx_grid_set_size (Evas_Object *object, int w, int h)
{
  elm_grid_size_set (object, w, h);
}

void
gfx_grid_get_size (const Evas_Object *object, int *w, int *h)
{
  elm_grid_size_get (object, w, h);
}

void
gfx_grid_add_pack (Evas_Object *object, Evas_Object *subobject, int x, int y, int w, int h)
{
  elm_grid_pack (object, subobject, x, y, w, h);
}

void
gfx_grid_unpack (Evas_Object *object, Evas_Object *subobject)
{
  elm_grid_unpack (object, subobject);
}

void
gfx_grid_set_pack (Evas_Object *subobject, Evas_Coord x, Evas_Coord y, Evas_Coord w, Evas_Coord h)
{
  elm_grid_pack_set (subobject, x, y, w, h);
}

void
gfx_grid_get_pack (Evas_Object *subobject, Evas_Coord *x, Evas_Coord *y, Evas_Coord *w, Evas_Coord *h)
{
  elm_grid_pack_get (subobject, x, y, w, h);
}

Eina_List *
gfx_grid_get_children (const Evas_Object *object)
{
  return elm_grid_children_get (object);
}

void
gfx_grid_clear (Evas_Object *object, Eina_Bool clear)
{
  elm_grid_clear (object, clear);
}

/* Grid Functions - End */

/* Table Functions - Start */

Evas_Object *
gfx_object_add_table (Evas_Object *parent)
{
  Evas_Object *object = elm_table_add (parent);

  return object;
}

void
gfx_table_set_align (Evas_Object *object, double horizontal, double vertical)
{
  elm_table_align_set (object, horizontal, vertical);
}

void
gfx_table_get_align (const Evas_Object *object, double *horizontal, double *vertical)
{
  elm_table_align_get (object, horizontal, vertical);
}

Evas_Object *
gfx_table_get_child (const Evas_Object *object, int col, int row)
{
  return elm_table_child_get (object, col, row);
}

void
gfx_table_clear (Evas_Object *object, Eina_Bool clear)
{
  elm_table_clear (object, clear);
}

void
gfx_table_set_homogeneous (Evas_Object *object, Eina_Bool homogeneous)
{
  elm_table_homogeneous_set (object, homogeneous);
}

Eina_Bool
gfx_table_get_homogeneous (const Evas_Object *object)
{
  return elm_table_homogeneous_get (object);
}

void
gfx_table_pack (Evas_Object *object, Evas_Object *subobject, int col, int row, int colspan, int rowspan)
{
  elm_table_pack (object, subobject, col, row, colspan, rowspan);
}

void
gfx_table_set_pack (Evas_Object *subobject, int col, int row, int colspan, int rowspan)
{
  elm_table_pack_set (subobject, col, row, colspan, rowspan);
}

void
gfx_table_get_pack (Evas_Object *subobject, int *col, int *row, int *colspan, int *rowspan)
{
  elm_table_pack_get (subobject, col, row, colspan, rowspan);
}

void
gfx_table_set_padding (Evas_Object *object, Evas_Coord horizontal, Evas_Coord vertical)
{
  elm_table_padding_set (object, horizontal, vertical);
}

void
gfx_table_get_padding (Evas_Object *object, Evas_Coord *horizontal, Evas_Coord *vertical)
{
  elm_table_padding_get (object, horizontal, vertical);
}

void
gfx_table_unpack (Evas_Object *object, Evas_Object *subobject)
{
  elm_table_unpack (object, subobject);
}

/* Table Functions - End */

/* Scroller Functions - Start */

Evas_Object *
gfx_object_add_scroller (Evas_Object *parent)
{
  Evas_Object *object = elm_scroller_add (parent);

  return object;
}

void
gfx_scroller_set_policy (Evas_Object *object, Elm_Scroller_Policy policy_h, Elm_Scroller_Policy policy_v)
{
  elm_scroller_policy_set (object, policy_h, policy_v);
}

void
gfx_scroller_get_policy (const Evas_Object *object, Elm_Scroller_Policy *policy_h, Elm_Scroller_Policy *policy_v)
{
  elm_scroller_policy_get (object, policy_h, policy_v);
}

void
gfx_scroller_set_region (Evas_Object *object, Evas_Coord x, Evas_Coord y, Evas_Coord w, Evas_Coord h)
{
  elm_scroller_region_show (object, x, y, w, h);
}

void
gfx_scroller_get_region (const Evas_Object *object, Evas_Coord *x, Evas_Coord *y, Evas_Coord *w, Evas_Coord *h)
{
  elm_scroller_region_get (object, x, y, w, h);
}

void
gfx_scroller_get_position (const Evas_Object *object, Evas_Coord *x, Evas_Coord *y)
{
  elm_scroller_region_get (object, x, y, NULL, NULL);
}

void
gfx_scroller_set_pagesize (Evas_Object *object, Evas_Coord w, Evas_Coord h)
{
  elm_scroller_page_size_set (object, w, h);
}

void
gfx_scroller_get_pagesize (const Evas_Object *object, Evas_Coord *w, Evas_Coord *h)
{
  elm_scroller_page_size_get (object, w, h);
}

void
gfx_scroller_get_currentpage (const Evas_Object *object, int *hp, int *vp)
{
  elm_scroller_current_page_get (object, hp, vp);
}

void
gfx_scroller_show_page (Evas_Object *object, int hp, int vp)
{
  elm_scroller_page_show (object, hp, vp);
}

void
gfx_scroller_set_bounce (Evas_Object *object, Eina_Bool h_bounce, Eina_Bool v_bounce)
{
  elm_scroller_bounce_set (object, h_bounce, v_bounce);
}

void
gfx_scroller_get_bounce (const Evas_Object *object, Eina_Bool *h_bounce, Eina_Bool *v_bounce)
{
  elm_scroller_bounce_get (object, h_bounce, v_bounce);
}

/* Scroller Functions - End */

/* Frame Functions - Start */

Evas_Object *
gfx_object_add_frame (Evas_Object *parent)
{
  Evas_Object *object = elm_frame_add (parent);

  return object;
}

void
gfx_frame_set_autocollapse (Evas_Object *object, Eina_Bool autocollapse)
{
  elm_frame_autocollapse_set (object, autocollapse);
}

Eina_Bool
gfx_frame_get_autocollapse (const Evas_Object *object)
{
  return elm_frame_autocollapse_get (object);
}

void
gfx_frame_set_collapse (Evas_Object *object, Eina_Bool collapse)
{
  elm_frame_collapse_set (object, collapse);
}

Eina_Bool
gfx_frame_get_collapse (const Evas_Object *object)
{
  return elm_frame_collapse_get (object);
}

void
gfx_frame_set_collapsible (Evas_Object *object, Eina_Bool collapsible)
{
  elm_frame_collapse_set (object, collapsible);
}

Eina_Bool
gfx_frame_get_collapsible (const Evas_Object *object)
{
  return elm_frame_collapse_get (object);
}

/* Frame Functions - End */

/* Object Management Functions - Start */

void
gfx_object_set_text (Evas_Object *object, const char *text)
{
  elm_object_text_set (object, text);
}

const char *
gfx_object_get_text (const Evas_Object *object)
{
  return elm_object_text_get (object);
}

void
gfx_object_set_content (Evas_Object *object, Evas_Object *content)
{
  elm_object_content_set (object, content);
}

Evas_Object *
gfx_object_get_content (const Evas_Object *object)
{
  return elm_object_content_get (object);
}

void
gfx_object_set_parttext (Evas_Object *object, const char *part, const char *text)
{
  elm_object_part_text_set (object, part, text);
}

void
gfx_object_set_partcontent (Evas_Object *object, const char *part, Evas_Object *content)
{
  elm_object_part_content_set (object, part, content);
}

/* Object Management Functions - End */

/* Entry and State Functions - Start */

void
gfx_entry_set_text (Evas_Object *object, const char *text)
{
  elm_entry_entry_set (object, text);
}

const char *
gfx_entry_get_text (const Evas_Object *object)
{
  return elm_entry_entry_get (object);
}

void
gfx_check_set_state (Evas_Object *object, Eina_Bool checked)
{
  elm_check_state_set (object, checked);
}

Eina_Bool
gfx_check_get_state (const Evas_Object *object)
{
  return elm_check_state_get (object);
}

void
gfx_radio_set_value (Evas_Object *object, int value)
{
  elm_radio_value_set (object, value);
}

int
gfx_radio_get_value (const Evas_Object *object)
{
  return elm_radio_value_get (object);
}

void
gfx_slider_set_value (Evas_Object *object, double value)
{
  elm_slider_value_set (object, value);
}

double
gfx_slider_get_value (const Evas_Object *object)
{
  return elm_slider_value_get (object);
}

/* Entry and State Functions - End */

/* Genlist Functions - Start */

Elm_Object_Item *
gfx_genlist_add_item (Evas_Object *object, const Elm_Genlist_Item_Class *itemclass, const void *data, Elm_Object_Item *parent, Elm_Genlist_Item_Type flags, Evas_Smart_Cb function, const void *function_data)
{
  return elm_genlist_item_append (object, itemclass, data, parent, flags, function, function_data);
}

void
gfx_genlist_clear (Evas_Object *object)
{
  elm_genlist_clear (object);
}

Elm_Genlist_Item_Class *
gfx_genlist_add_itemclass (void)
{
  return elm_genlist_item_class_new ();
}

void
gfx_genlist_free_itemclass (Elm_Genlist_Item_Class *itemclass)
{
  elm_genlist_item_class_free (itemclass);
}

/* Genlist Functions - End */
