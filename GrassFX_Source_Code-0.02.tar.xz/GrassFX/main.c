#include <Elementary.h>
#include <stdio.h>
#include "gfx.h"

static void
_on_window_del (void *data, Evas_Object *obj, void *event_info)
{
  (void) data;
  (void) obj;
  (void) event_info;

  gfx_exit ();
}

static void
_on_button_clicked (void *data, Evas_Object *obj, void *event_info)
{
  (void) data;
  (void) obj;
  (void) event_info;

  printf ("Button clicked!\n");
}

static void
_on_checkbox_changed (void *data, Evas_Object *obj, void *event_info)
{
  (void) data;
  (void) event_info;

  Eina_Bool state = gfx_check_get_state (obj);
  printf ("Checkbox status: %s\n", state ? "Enabled" : "Disabled");
}

static void
_on_slider_changed (void *data, Evas_Object *obj, void *event_info)
{
  (void) data;
  (void) event_info;

  double val = gfx_slider_get_value (obj);
  printf ("Slider value: %.2f\n", val);
}

static char *
_genlist_text_get (void *data, Evas_Object *obj, const char *part)
{
  (void) obj;
  (void) part;

  const char *str = (const char *) data;
  return strdup (str);
}

static Evas_Object *
_create_widgets_section (Evas_Object *win)
{
  Evas_Object *box;
  Evas_Object *label;
  Evas_Object *button;
  Evas_Object *checkbox;
  Evas_Object *radio1;
  Evas_Object *radio2;
  Evas_Object *entry;
  Evas_Object *slider;
  Evas_Object *spinner;
  Evas_Object *combobox;
  Evas_Object *progressbar;
  Evas_Object *bubble;
  Evas_Object *clock_widget;
  Evas_Object *calendar;
  Evas_Object *separator;

  box = gfx_object_add_box (win);
  gfx_box_set_horizontal (box, EINA_FALSE);
  gfx_box_set_padding (box, 0, 8);
  evas_object_show (box);

  label = gfx_object_add_label (win);
  gfx_object_set_text (label, "<b>1. Basic Controls & Widgets</b>");
  evas_object_show (label);
  gfx_box_pack_end (box, label);

  button = gfx_object_add_button (win);
  gfx_object_set_text (button, "Execute Action");
  evas_object_smart_callback_add (button, "clicked", _on_button_clicked, NULL);
  evas_object_show (button);
  gfx_box_pack_end (box, button);

  checkbox = gfx_object_add_checkbutton (win);
  gfx_object_set_text (checkbox, "Enable Feature");
  gfx_check_set_state (checkbox, EINA_TRUE);
  evas_object_smart_callback_add (checkbox, "changed", _on_checkbox_changed, NULL);
  evas_object_show (checkbox);
  gfx_box_pack_end (box, checkbox);

  radio1 = gfx_object_add_radiobutton (win);
  gfx_object_set_text (radio1, "Option A");
  gfx_radio_set_value (radio1, 10);
  evas_object_show (radio1);
  gfx_box_pack_end (box, radio1);

  radio2 = gfx_object_add_radiobutton (win);
  gfx_object_set_text (radio2, "Option B");
  gfx_radio_set_value (radio2, 20);
  elm_radio_group_add (radio2, radio1);
  evas_object_show (radio2);
  gfx_box_pack_end (box, radio2);

  entry = gfx_object_add_entry (win);
  gfx_entry_set_text (entry, "Editable input field...");
  evas_object_show (entry);
  gfx_box_pack_end (box, entry);

  slider = gfx_object_add_slider (win);
  gfx_slider_set_value (slider, 0.5);
  evas_object_smart_callback_add (slider, "changed", _on_slider_changed, NULL);
  evas_object_show (slider);
  gfx_box_pack_end (box, slider);

  spinner = gfx_object_add_spinner (win);
  elm_spinner_min_max_set (spinner, 0.0, 100.0);
  elm_spinner_value_set (spinner, 25.0);
  evas_object_show (spinner);
  gfx_box_pack_end (box, spinner);

  combobox = gfx_object_add_combobox (win);
  gfx_object_set_text (combobox, "Select Item");
  elm_combobox_hover_begin (combobox);
  evas_object_show (combobox);
  gfx_box_pack_end (box, combobox);

  progressbar = gfx_object_add_progressbar (win);
  elm_progressbar_value_set (progressbar, 0.65);
  evas_object_show (progressbar);
  gfx_box_pack_end (box, progressbar);

  bubble = gfx_object_add_bubble (win);
  gfx_object_set_text (bubble, "Notification");
  gfx_object_set_parttext (bubble, "info", "System Message");
  evas_object_show (bubble);
  gfx_box_pack_end (box, bubble);

  clock_widget = gfx_object_add_clock (win);
  evas_object_show (clock_widget);
  gfx_box_pack_end (box, clock_widget);

  calendar = gfx_object_add_calendar (win);
  evas_object_show (calendar);
  gfx_box_pack_end (box, calendar);

  separator = gfx_object_add_separator (win);
  elm_separator_horizontal_set (separator, EINA_TRUE);
  evas_object_show (separator);
  gfx_box_pack_end (box, separator);

  return box;
}

static Evas_Object *
_create_container_section (Evas_Object *win)
{
  Evas_Object *frame;
  Evas_Object *frame_box;
  Evas_Object *label;
  Evas_Object *grid;
  Evas_Object *table;
  Evas_Object *grid_btn1;
  Evas_Object *grid_btn2;
  Evas_Object *tbl_btn1;
  Evas_Object *tbl_btn2;

  frame = gfx_object_add_frame (win);
  gfx_object_set_text (frame, "2. Layout & Container Demonstrations");
  gfx_frame_set_collapsible (frame, EINA_TRUE);
  gfx_frame_set_collapse (frame, EINA_FALSE);
  evas_object_show (frame);

  frame_box = gfx_object_add_box (win);
  gfx_box_set_horizontal (frame_box, EINA_FALSE);
  gfx_box_set_padding (frame_box, 0, 10);
  evas_object_show (frame_box);

  label = gfx_object_add_label (win);
  gfx_object_set_text (label, "<i>Grid Layout (100x100 Virtual Units):</i>");
  evas_object_show (label);
  gfx_box_pack_end (frame_box, label);

  grid = gfx_object_add_grid (win);
  gfx_grid_set_size (grid, 100, 100);

  grid_btn1 = gfx_object_add_button (win);
  gfx_object_set_text (grid_btn1, "Grid (0,0 50x50)");
  evas_object_show (grid_btn1);
  gfx_grid_add_pack (grid, grid_btn1, 0, 0, 50, 50);

  grid_btn2 = gfx_object_add_button (win);
  gfx_object_set_text (grid_btn2, "Grid (50,0 50x50)");
  evas_object_show (grid_btn2);
  gfx_grid_add_pack (grid, grid_btn2, 50, 0, 50, 50);

  evas_object_size_hint_min_set (grid, 200, 80);
  evas_object_show (grid);
  gfx_box_pack_end (frame_box, grid);

  label = gfx_object_add_label (win);
  gfx_object_set_text (label, "<i>Table Layout (Rows & Columns):</i>");
  evas_object_show (label);
  gfx_box_pack_end (frame_box, label);

  table = gfx_object_add_table (win);
  gfx_table_set_padding (table, 5, 5);

  tbl_btn1 = gfx_object_add_button (win);
  gfx_object_set_text (tbl_btn1, "Row 0, Col 0");
  evas_object_show (tbl_btn1);
  gfx_table_pack (table, tbl_btn1, 0, 0, 1, 1);

  tbl_btn2 = gfx_object_add_button (win);
  gfx_object_set_text (tbl_btn2, "Row 0, Col 1");
  evas_object_show (tbl_btn2);
  gfx_table_pack (table, tbl_btn2, 1, 0, 1, 1);

  evas_object_show (table);
  gfx_box_pack_end (frame_box, table);

  gfx_object_set_content (frame, frame_box);

  return frame;
}

static Evas_Object *
_create_genlist_section (Evas_Object *win)
{
  Evas_Object *genlist;
  Elm_Genlist_Item_Class *itc;

  genlist = elm_genlist_add (win);
  evas_object_size_hint_min_set (genlist, 300, 150);

  itc = gfx_genlist_add_itemclass ();
  itc->item_style = "default";
  itc->func.text_get = _genlist_text_get;
  itc->func.content_get = NULL;
  itc->func.state_get = NULL;
  itc->func.del = NULL;

  gfx_genlist_add_item (genlist, itc, "Genlist Entry 1", NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);
  gfx_genlist_add_item (genlist, itc, "Genlist Entry 2", NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);
  gfx_genlist_add_item (genlist, itc, "Genlist Entry 3", NULL, ELM_GENLIST_ITEM_NONE, NULL, NULL);

  gfx_genlist_free_itemclass (itc);

  evas_object_show (genlist);

  return genlist;
}

int
main (int argc, char **argv)
{
  Evas_Object *win;
  Evas_Object *scroller;
  Evas_Object *main_box;
  Evas_Object *widgets_section;
  Evas_Object *container_section;
  Evas_Object *genlist_section;

  gfx_init (argc, argv);

  win = gfx_object_add_feature_window ("main_window", "Gfx Library Test Suite");
  if (!win)
    {
      gfx_shutdown ();
      return -1;
    }

  gfx_window_set_minsize (win, 480, 640);
  gfx_window_set_autodel (win, EINA_TRUE);
  gfx_window_set_center (win, EINA_TRUE, EINA_TRUE);
  evas_object_smart_callback_add (win, "delete,request", _on_window_del, NULL);

  main_box = gfx_object_add_box (win);
  gfx_box_set_horizontal (main_box, EINA_FALSE);
  gfx_box_set_homogeneous (main_box, EINA_FALSE);
  gfx_box_set_padding (main_box, 0, 15);
  evas_object_show (main_box);

  widgets_section = _create_widgets_section (win);
  gfx_box_pack_end (main_box, widgets_section);

  container_section = _create_container_section (win);
  gfx_box_pack_end (main_box, container_section);

  genlist_section = _create_genlist_section (win);
  gfx_box_pack_end (main_box, genlist_section);

  scroller = gfx_object_add_scroller (win);
  gfx_scroller_set_policy (scroller, ELM_SCROLLER_POLICY_AUTO, ELM_SCROLLER_POLICY_AUTO);
  gfx_scroller_set_bounce (scroller, EINA_FALSE, EINA_TRUE);
  gfx_object_set_content (scroller, main_box);
  evas_object_show (scroller);

  gfx_window_ratio_scale (win, scroller);

  evas_object_show (win);

  gfx_run ();

  gfx_shutdown ();

  return 0;
}
