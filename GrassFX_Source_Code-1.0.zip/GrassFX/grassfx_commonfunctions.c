#include <Elementary.h>
#include <Ecore.h>
#include <stdio.h>
#include "grassfx.h"

/* General Functions - Start */

int gfx_init(int argc, char **argv)
{
	int ret;

	ret = elm_init(argc, argv);
	if (ret < 0)
		return ret;

	ecore_init();
	return ret;
}

int gfx_run(void)
{
	elm_run();
	return 0;
}

int gfx_exit(void)
{
	ecore_main_loop_quit();
	elm_exit();
	return 0;
}

int gfx_shutdown(void)
{
	int ret;

	ret = elm_shutdown();
	ecore_shutdown();
	return ret;
}

/* General Functions - End */
