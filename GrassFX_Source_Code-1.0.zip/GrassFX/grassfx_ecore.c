#include <Elementary.h>
#include <Ecore.h>
#include <stdio.h>
#include "grassfx.h"

static Eina_Bool _gfx_exe_del_cb(void *data, int type, void *event)
{
	Ecore_Exe_Event_Del *ev = event;
	Ecore_Exe_Cb cb = data;
	void *exe_data = NULL;

	(void)type;

	if (!ev || !cb)
		return ECORE_CALLBACK_PASS_ON;

	if (ev->exe)
		exe_data = ecore_exe_data_get(ev->exe);

	cb(exe_data, ev->exe);
	return ECORE_CALLBACK_PASS_ON;
}

/* Main Loop Functions - Start */

void gfx_start_mainloop(void)
{
	ecore_main_loop_begin();
}

double gfx_get_looptime(void)
{
	return ecore_loop_time_get();
}

/* Main Loop Functions - End */

/* Timer Functions - Start */

Ecore_Timer *gfx_add_timer(double in_seconds, Ecore_Task_Cb func, const void *data)
{
	Ecore_Timer *timer;

	if (!func)
		return NULL;

	timer = ecore_timer_add(in_seconds, func, data);
	return timer;
}

void gfx_del_timer(Ecore_Timer *timer)
{
	if (!timer)
		return;

	ecore_timer_del(timer);
}

void gfx_timer_set_interval(Ecore_Timer *timer, double in_seconds)
{
	if (!timer)
		return;

	ecore_timer_interval_set(timer, in_seconds);
}

double gfx_timer_get_interval(const Ecore_Timer *timer)
{
	if (!timer)
		return 0.0;

	return ecore_timer_interval_get(timer);
}

void gfx_timer_delay(Ecore_Timer *timer, double add)
{
	if (!timer)
		return;

	ecore_timer_delay(timer, add);
}

void gfx_timer_freeze(Ecore_Timer *timer)
{
	if (!timer)
		return;

	ecore_timer_freeze(timer);
}

void gfx_timer_thaw(Ecore_Timer *timer)
{
	if (!timer)
		return;

	ecore_timer_thaw(timer);
}

/* Timer Functions - End */

/* Idler Functions - Start */

Ecore_Idler *gfx_add_idler(Ecore_Task_Cb func, const void *data)
{
	Ecore_Idler *idler;

	if (!func)
		return NULL;

	idler = ecore_idler_add(func, data);
	return idler;
}

void *gfx_del_idler(Ecore_Idler *idler)
{
	void *ret;

	if (!idler)
		return NULL;

	ret = ecore_idler_del(idler);
	return ret;
}

/* Idler Functions - End */

/* Poller Functions - Start */

Ecore_Poller *gfx_add_poller(Ecore_Poller_Type type, int interval, Ecore_Task_Cb func, const void *data)
{
	Ecore_Poller *poller;

	if (!func)
		return NULL;

	poller = ecore_poller_add(type, interval, func, data);
	return poller;
}

void *gfx_del_poller(Ecore_Poller *poller)
{
	void *ret;

	if (!poller)
		return NULL;

	ret = ecore_poller_del(poller);
	return ret;
}

/* Poller Functions - End */

/* Thread Functions - Start */

Ecore_Thread *gfx_run_thread(Ecore_Thread_Cb func_blocking, Ecore_Thread_Cb func_end, Ecore_Thread_Cb func_cancel, const void *data)
{
	Ecore_Thread *thread;

	if (!func_blocking)
		return NULL;

	thread = ecore_thread_run(func_blocking, func_end, func_cancel, data);
	return thread;
}

Ecore_Thread *gfx_thread_run_feedback(Ecore_Thread_Cb func_heavy, Ecore_Thread_Notify_Cb func_notify, Ecore_Thread_Cb func_end, Ecore_Thread_Cb func_cancel, const void *data, Eina_Bool try_no_queue)
{
	Ecore_Thread *thread;

	if (!func_heavy)
		return NULL;

	thread = ecore_thread_feedback_run(func_heavy, func_notify, func_end, func_cancel, data, try_no_queue);
	return thread;
}

Eina_Bool gfx_thread_cancel(Ecore_Thread *th)
{
	if (!th)
		return EINA_FALSE;

	return ecore_thread_cancel(th);
}

void gfx_thread_add_localdata(Ecore_Thread *th, const char *key, void *value, Eina_Free_Cb cb, Eina_Bool direct)
{
	if (!th || !key)
		return;

	ecore_thread_local_data_add(th, key, value, cb, direct);
}

/* Thread Functions - End */

/* Process Execution Functions - Start */

Ecore_Exe *gfx_execute_run(const char *exe_command, const void *data)
{
	Ecore_Exe *exe;

	if (!exe_command)
		return NULL;

	exe = ecore_exe_run(exe_command, data);
	return exe;
}

Ecore_Exe *gfx_execute_run_cb(const char *exe_command, Ecore_Exe_Cb func, const void *data)
{
	Ecore_Exe *exe;

	if (!exe_command || !func)
		return NULL;

	exe = ecore_exe_run(exe_command, (void *)data);
	if (!exe)
		return NULL;

	ecore_event_handler_add(ECORE_EXE_EVENT_DEL, _gfx_exe_del_cb, (void *)func);
	return exe;
}

void gfx_execute_terminate(Ecore_Exe *exe)
{
	if (!exe)
		return;

	ecore_exe_terminate(exe);
}

void gfx_execute_kill(Ecore_Exe *exe)
{
	if (!exe)
		return;

	ecore_exe_kill(exe);
}

pid_t gfx_execute_get_pid(const Ecore_Exe *exe)
{
	if (!exe)
		return -1;

	return ecore_exe_pid_get(exe);
}

void gfx_execute_free(Ecore_Exe *exe)
{
	if (!exe)
		return;

	ecore_exe_free(exe);
}

/* Process Execution Functions - End */

/* File Descriptor Handler Functions - Start */

Ecore_Fd_Handler *gfx_add_fdhandler(int fd, Ecore_Fd_Handler_Flags flags, Ecore_Fd_Cb func, const void *data, Ecore_Fd_Cb bufd_func, const void *bufd_data)
{
	Ecore_Fd_Handler *handler;

	if (fd < 0 || !func)
		return NULL;

	handler = ecore_main_fd_handler_add(fd, flags, func, data, bufd_func, bufd_data);
	return handler;
}

void *gfx_del_fdhandler(Ecore_Fd_Handler *fd_handler)
{
	void *ret;

	if (!fd_handler)
		return NULL;

	ret = ecore_main_fd_handler_del(fd_handler);
	return ret;
}

/* File Descriptor Handler Functions - End */

/* Event Handler Functions - Start */

Ecore_Event_Handler *gfx_add_eventhandler(int type, Ecore_Event_Handler_Cb func, const void *data)
{
	Ecore_Event_Handler *handler;

	if (type < 0 || !func)
		return NULL;

	handler = ecore_event_handler_add(type, func, data);
	return handler;
}

/* Event Handler Functions - End */
