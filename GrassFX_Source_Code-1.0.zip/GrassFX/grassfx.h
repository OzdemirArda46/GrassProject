#ifndef GRASSFX_H
#define GRASSFX_H

#include <Elementary.h>
#include <Ecore.h>
#include <Evas.h>
#include <sys/types.h>

typedef void (*Gfx_Callback)(void *data, Evas_Object *object, void *event_info);
#define GFX_CALLBACK(func_name) void func_name(void *data, Evas_Object *object, void *event_info)

/* General Functions - Start */

int gfx_init(int argc, char **argv);
int gfx_run(void);
int gfx_exit(void);
int gfx_shutdown(void);

/* General Functions - End */

/* Main Loop Functions - Start */

void gfx_start_mainloop(void);
double gfx_get_looptime(void);

/* Main Loop Functions - End */

/* Timer Functions - Start */

Ecore_Timer *gfx_add_timer(double in_seconds, Ecore_Task_Cb func, const void *data);
void gfx_del_timer(Ecore_Timer *timer);
void gfx_timer_set_interval(Ecore_Timer *timer, double in_seconds);
double gfx_timer_get_interval(const Ecore_Timer *timer);
void gfx_timer_delay(Ecore_Timer *timer, double add);
void gfx_timer_freeze(Ecore_Timer *timer);
void gfx_timer_thaw(Ecore_Timer *timer);

/* Timer Functions - End */

/* Idler Functions - Start */

Ecore_Idler *gfx_add_idler(Ecore_Task_Cb func, const void *data);
void *gfx_del_idler(Ecore_Idler *idler);

/* Idler Functions - End */

/* Poller Functions - Start */

Ecore_Poller *gfx_add_poller(Ecore_Poller_Type type, int interval, Ecore_Task_Cb func, const void *data);
void *gfx_del_poller(Ecore_Poller *poller);

/* Poller Functions - End */

/* Thread Functions - Start */

Ecore_Thread *gfx_run_thread(Ecore_Thread_Cb func_blocking, Ecore_Thread_Cb func_end, Ecore_Thread_Cb func_cancel, const void *data);
Ecore_Thread *gfx_thread_run_feedback(Ecore_Thread_Cb func_heavy, Ecore_Thread_Notify_Cb func_notify, Ecore_Thread_Cb func_end, Ecore_Thread_Cb func_cancel, const void *data, Eina_Bool try_no_queue);
Eina_Bool gfx_thread_cancel(Ecore_Thread *th);
void gfx_thread_add_localdata(Ecore_Thread *th, const char *key, void *value, Eina_Free_Cb cb, Eina_Bool direct);

/* Thread Functions - End */

/* Process Execution Functions - Start */

Ecore_Exe *gfx_execute_run(const char *exe_command, const void *data);
Ecore_Exe *gfx_execute_run_cb(const char *exe_command, Ecore_Exe_Cb func, const void *data);
void gfx_execute_terminate(Ecore_Exe *exe);
void gfx_execute_kill(Ecore_Exe *exe);
pid_t gfx_execute_get_pid(const Ecore_Exe *exe);
void gfx_execute_free(Ecore_Exe *exe);

/* Process Execution Functions - End */

/* File Descriptor Handler Functions - Start */

Ecore_Fd_Handler *gfx_add_fdhandler(int fd, Ecore_Fd_Handler_Flags flags, Ecore_Fd_Cb func, const void *data, Ecore_Fd_Cb bufd_func, const void *bufd_data);
void *gfx_del_fdhandler(Ecore_Fd_Handler *fd_handler);

/* File Descriptor Handler Functions - End */

/* Event Handler Functions - Start */

Ecore_Event_Handler *gfx_add_eventhandler(int type, Ecore_Event_Handler_Cb func, const void *data);

/* Event Handler Functions - End */

/* Canvas and Basic Object Management - Start */

Evas *gfx_object_get_evas(const Evas_Object *object);
void gfx_object_show(Evas_Object *object);
void gfx_object_hide(Evas_Object *object);
void gfx_object_del(Evas_Object *object);
void gfx_object_raise(Evas_Object *object);
void gfx_object_lower(Evas_Object *object);
void gfx_object_set_size_hintweight(Evas_Object *object, double x, double y);
void gfx_object_set_size_hintalign(Evas_Object *object, double x, double y);

/* Canvas and Basic Object Management - End */

/* Geometry, Position and Color - Start */

void gfx_object_move(Evas_Object *object, Evas_Coord x, Evas_Coord y);
void gfx_object_resize(Evas_Object *object, Evas_Coord w, Evas_Coord h);
void gfx_object_get_geometry(Evas_Object *object, Evas_Coord *x, Evas_Coord *y, Evas_Coord *w, Evas_Coord *h);
void gfx_object_set_color(Evas_Object *object, int r, int g, int b, int a);
void gfx_object_get_color(const Evas_Object *object, int *r, int *g, int *b, int *a);
void gfx_object_set_minsize(Evas_Object *object, Evas_Coord w, Evas_Coord h);
void gfx_object_set_maxsize(Evas_Object *object, Evas_Coord w, Evas_Coord h);

/* Geometry, Position and Color - End */

/* Object Creation / Factory - Start */

Evas_Object *gfx_object_add_rectangle(Evas *canvas);
Evas_Object *gfx_object_add_rawimage(Evas *canvas);
Evas_Object *gfx_object_add_text(Evas *canvas);
Evas_Object *gfx_object_add_textblock(Evas *canvas);

/* Object Creation / Factory - End */

/* Image Operations - Start */

void gfx_object_set_imagefile(Evas_Object *object, const char *file, const char *key);
void gfx_object_set_imagefilled(Evas_Object *object, Eina_Bool filled);
void gfx_object_set_imagesize(Evas_Object *object, int w, int h);
void gfx_object_get_imagesize(Evas_Object *object, int *w, int *h);

/* Image Operations - End */

/* Text Operations - Start */

Eina_Bool gfx_object_set_textfont(Evas_Object *object, const char *font, Evas_Font_Size size);
void gfx_object_set_rawtext(Evas_Object *object, const char *text);
const char *gfx_object_get_rawtext(const Evas_Object *object);
Eina_Bool gfx_object_set_textblockmarkup(Evas_Object *object, const char *text);

/* Text Operations - End */

/* Events and Interaction - Start */

void gfx_object_add_eventcallback(Evas_Object *object, Evas_Callback_Type type, Evas_Object_Event_Cb func, const void *data);
void gfx_object_add_smartcallback(Evas_Object *object, const char *event, Evas_Smart_Cb func, const void *data);
void gfx_object_set_focus(Evas_Object *object, Eina_Bool focus);

/* Events and Interaction - End */

/* Cropping / Masking - Start */

void gfx_object_set_clip(Evas_Object *object, Evas_Object *clip);
void gfx_object_unset_clip(Evas_Object *object);

/* Cropping / Masking - End */

/* Window Functions - Start */

Evas_Object *gfx_object_new_feature_window(const char *name, const char *title);
Evas_Object *gfx_object_new_standard_window(Evas_Object *parent, const char *name, Elm_Win_Type type);
int gfx_window_set_title(Evas_Object *object, const char *title);
int gfx_window_set_autodel(Evas_Object *object, Eina_Bool autodel);
int gfx_window_set_center(Evas_Object *object, Eina_Bool h, Eina_Bool v);
int gfx_window_set_minsize(Evas_Object *object, int w, int h);
int gfx_window_set_fullscreen(Evas_Object *object, Eina_Bool full);
int gfx_window_set_active(Evas_Object *object);
int gfx_window_set_iconified(Evas_Object *object, Eina_Bool iconified);
int gfx_window_set_sticky(Evas_Object *object, Eina_Bool sticky);
int gfx_window_proportion_scale(Evas_Object *object, Evas_Object *subobject);
void gfx_window_set_autohide(Evas_Object *object, Eina_Bool autohide);
void gfx_window_set_borderless(Evas_Object *object, Eina_Bool borderless);
Eina_Bool gfx_window_get_borderless(const Evas_Object *object);
void gfx_window_set_shaped(Evas_Object *object, Eina_Bool shaped);
Eina_Bool gfx_window_get_shaped(const Evas_Object *object);
void gfx_window_set_alpha(Evas_Object *object, Eina_Bool alpha);
Eina_Bool gfx_window_get_alpha(const Evas_Object *object);

/* Window Functions - End */

/* Serial Window Functions - Start */

Evas_Object *gfx_object_create_window(Evas_Object *parent, const char *name, Elm_Win_Type type, const char *title, Evas_Coord x, Evas_Coord y);

/* Serial Window Functions - End */

/* Widget Addition Functions - Start */

Evas_Object *gfx_object_add_button(Evas_Object *parent);
Evas_Object *gfx_object_add_checkbutton(Evas_Object *parent);
Evas_Object *gfx_object_add_radiobutton(Evas_Object *parent);
Evas_Object *gfx_object_add_entry(Evas_Object *parent);
Evas_Object *gfx_object_add_slider(Evas_Object *parent);
Evas_Object *gfx_object_add_spinner(Evas_Object *parent);
Evas_Object *gfx_object_add_combobox(Evas_Object *parent);
Evas_Object *gfx_object_add_label(Evas_Object *parent);
Evas_Object *gfx_object_add_icon(Evas_Object *parent);
Evas_Object *gfx_object_add_image(Evas_Object *parent);
Evas_Object *gfx_object_add_progressbar(Evas_Object *parent);
Evas_Object *gfx_object_add_bubble(Evas_Object *parent);
Evas_Object *gfx_object_add_clock(Evas_Object *parent);
Evas_Object *gfx_object_add_calendar(Evas_Object *parent);
Evas_Object *gfx_object_add_separator(Evas_Object *parent);
Evas_Object *gfx_object_add_popup(Evas_Object *parent);

/* Widget Addition Functions - End */

/* Box Functions - Start */

Evas_Object *gfx_object_add_box(Evas_Object *parent);
void gfx_box_set_horizontal(Evas_Object *object, Eina_Bool horizontal);
Eina_Bool gfx_box_get_horizontal(const Evas_Object *object);
void gfx_box_pack_start(Evas_Object *object, Evas_Object *child);
void gfx_box_pack_end(Evas_Object *object, Evas_Object *child);
void gfx_box_pack_before(Evas_Object *object, Evas_Object *child, Evas_Object *before);
void gfx_box_pack_after(Evas_Object *object, Evas_Object *child, Evas_Object *after);
void gfx_box_unpack(Evas_Object *object, Evas_Object *child);
void gfx_box_unpack_all(Evas_Object *object);
void gfx_box_set_homogeneous(Evas_Object *object, Eina_Bool homogeneous);
Eina_Bool gfx_box_get_homogeneous(Evas_Object *object);
void gfx_box_set_padding(Evas_Object *object, Evas_Coord horizontal, Evas_Coord vertical);
void gfx_box_get_padding(Evas_Object *object, Evas_Coord *horizontal, Evas_Coord *vertical);
void gfx_box_set_align(Evas_Object *object, double horizontal, double vertical);
void gfx_box_get_align(Evas_Object *object, double *horizontal, double *vertical);
Eina_List *gfx_box_get_children(const Evas_Object *object);
void gfx_box_clear(Evas_Object *object);
void gfx_box_set_layout(Evas_Object *object, Evas_Object_Box_Layout func, const void *data, Eina_Free_Cb free_data);

/* Box Functions - End */

/* Grid Functions - Start */

Evas_Object *gfx_object_add_grid(Evas_Object *parent);
void gfx_grid_set_size(Evas_Object *object, int w, int h);
void gfx_grid_get_size(const Evas_Object *object, int *w, int *h);
void gfx_grid_add_pack(Evas_Object *object, Evas_Object *subobject, int x, int y, int w, int h);
void gfx_grid_unpack(Evas_Object *object, Evas_Object *subobject);
void gfx_grid_set_pack(Evas_Object *subobject, Evas_Coord x, Evas_Coord y, Evas_Coord w, Evas_Coord h);
void gfx_grid_get_pack(Evas_Object *subobject, Evas_Coord *x, Evas_Coord *y, Evas_Coord *w, Evas_Coord *h);
Eina_List *gfx_grid_get_children(const Evas_Object *object);
void gfx_grid_clear(Evas_Object *object, Eina_Bool clear);

/* Grid Functions - End */

/* Table Functions - Start */

Evas_Object *gfx_object_add_table(Evas_Object *parent);
void gfx_table_set_align(Evas_Object *object, double horizontal, double vertical);
void gfx_table_get_align(const Evas_Object *object, double *horizontal, double *vertical);
Evas_Object *gfx_table_get_child(const Evas_Object *object, int col, int row);
void gfx_table_clear(Evas_Object *object, Eina_Bool clear);
void gfx_table_set_homogeneous(Evas_Object *object, Eina_Bool homogeneous);
Eina_Bool gfx_table_get_homogeneous(const Evas_Object *object);
void gfx_table_pack(Evas_Object *object, Evas_Object *subobject, int col, int row, int colspan, int rowspan);
void gfx_table_set_pack(Evas_Object *subobject, int col, int row, int colspan, int rowspan);
void gfx_table_get_pack(Evas_Object *subobject, int *col, int *row, int *colspan, int *rowspan);
void gfx_table_set_padding(Evas_Object *object, Evas_Coord horizontal, Evas_Coord vertical);
void gfx_table_get_padding(Evas_Object *object, Evas_Coord *horizontal, Evas_Coord *vertical);
void gfx_table_unpack(Evas_Object *object, Evas_Object *subobject);

/* Table Functions - End */

/* Scroller Functions - Start */

Evas_Object *gfx_object_add_scroller(Evas_Object *parent);
void gfx_scroller_set_policy(Evas_Object *object, Elm_Scroller_Policy policy_h, Elm_Scroller_Policy policy_v);
void gfx_scroller_get_policy(const Evas_Object *object, Elm_Scroller_Policy *policy_h, Elm_Scroller_Policy *policy_v);
void gfx_scroller_set_region(Evas_Object *object, Evas_Coord x, Evas_Coord y, Evas_Coord w, Evas_Coord h);
void gfx_scroller_get_region(const Evas_Object *object, Evas_Coord *x, Evas_Coord *y, Evas_Coord *w, Evas_Coord *h);
void gfx_scroller_get_position(const Evas_Object *object, Evas_Coord *x, Evas_Coord *y);
void gfx_scroller_set_pagesize(Evas_Object *object, Evas_Coord w, Evas_Coord h);
void gfx_scroller_get_pagesize(const Evas_Object *object, Evas_Coord *w, Evas_Coord *h);
void gfx_scroller_get_currentpage(const Evas_Object *object, int *hp, int *vp);
void gfx_scroller_show_page(Evas_Object *object, int hp, int vp);
void gfx_scroller_set_bounce(Evas_Object *object, Eina_Bool h_bounce, Eina_Bool v_bounce);
void gfx_scroller_get_bounce(const Evas_Object *object, Eina_Bool *h_bounce, Eina_Bool *v_bounce);

/* Scroller Functions - End */

/* Frame Functions - Start */

Evas_Object *gfx_object_add_frame(Evas_Object *parent);
void gfx_frame_set_autocollapse(Evas_Object *object, Eina_Bool autocollapse);
Eina_Bool gfx_frame_get_autocollapse(const Evas_Object *object);
void gfx_frame_set_collapse(Evas_Object *object, Eina_Bool collapse);
Eina_Bool gfx_frame_get_collapse(const Evas_Object *object);

/* Frame Functions - End */

/* Object Management Functions - Start */

void gfx_object_set_text(Evas_Object *object, const char *text);
const char *gfx_object_get_text(const Evas_Object *object);
void gfx_object_set_content(Evas_Object *object, Evas_Object *content);
Evas_Object *gfx_object_get_content(const Evas_Object *object);
Eina_Bool gfx_image_set_file(Evas_Object *object, const char *file, const char *group);
Eina_Bool gfx_icon_set_standard(Evas_Object *object, const char *name);
void gfx_object_set_parttext(Evas_Object *object, const char *part, const char *text);
void gfx_object_set_partcontent(Evas_Object *object, const char *part, Evas_Object *content);
Eina_Bool gfx_set_policy(unsigned int policy, int value);
void gfx_object_set_disabled(Evas_Object *object, Eina_Bool disabled);

/* Object Management Functions - End */

/* Entry and State Functions - Start */

void gfx_entry_set_text(Evas_Object *object, const char *text);
const char *gfx_entry_get_text(const Evas_Object *object);
void gfx_entry_set_singleline(Evas_Object *object, Eina_Bool single_line);
void gfx_entry_set_password(Evas_Object *object, Eina_Bool password);
void gfx_check_set_state(Evas_Object *object, Eina_Bool checked);
Eina_Bool gfx_check_get_state(const Evas_Object *object);
void gfx_radio_set_statevalue(Evas_Object *object, int value);
void gfx_radio_set_value(Evas_Object *object, int value);
int gfx_radio_get_value(const Evas_Object *object);
void gfx_radio_add_group(Evas_Object *object, Evas_Object *group);
void gfx_radio_set_pointervalue(Evas_Object *object, int *valuep);
void gfx_slider_set_minmax(Evas_Object *object, double min, double max);
void gfx_slider_set_unitformat(Evas_Object *object, const char *format);
void gfx_slider_set_value(Evas_Object *object, double value);
double gfx_slider_get_value(const Evas_Object *object);

/* Entry and State Functions - End */

/* Genlist Functions - Start */

Elm_Object_Item *gfx_genlist_add_item(Evas_Object *object, const Elm_Genlist_Item_Class *itemclass, const void *data, Elm_Object_Item *parent, Elm_Genlist_Item_Type flags, Evas_Smart_Cb function, const void *function_data);
void gfx_genlist_clear(Evas_Object *object);
Elm_Genlist_Item_Class *gfx_genlist_add_itemclass(void);
void gfx_genlist_free_itemclass(Elm_Genlist_Item_Class *itemclass);

/* Genlist Functions - End */

/* Background Functions - Start */

Evas_Object *gfx_object_add_background(Evas_Object *parent);
Eina_Bool gfx_background_set_file(Evas_Object *object, const char *file, const char *group);
void gfx_background_get_file(const Evas_Object *object, const char **file, const char **group);
void gfx_background_set_option(Evas_Object *object, Elm_Bg_Option option);
Elm_Bg_Option gfx_background_get_option(const Evas_Object *object);
void gfx_background_set_color(Evas_Object *object, int r, int g, int b);
void gfx_background_get_color(const Evas_Object *object, int *r, int *g, int *b);
void gfx_background_set_loadsize(Evas_Object *object, int w, int h);

/* Background Functions - End */

/* Menu Functions - Start */

Evas_Object *gfx_object_add_menu(Evas_Object *parent);
Elm_Object_Item *gfx_menu_add_item(Evas_Object *object, Elm_Object_Item *parent, const char *icon, const char *label, Evas_Smart_Cb func, const void *data);
Elm_Object_Item *gfx_menu_add_separator(Evas_Object *object, Elm_Object_Item *parent);
Elm_Object_Item *gfx_menu_add_submenu(Evas_Object *object, Elm_Object_Item *parent, const char *label);
void gfx_menu_move(Evas_Object *object, Evas_Coord x, Evas_Coord y);
void gfx_menu_close(Evas_Object *object);
Elm_Object_Item *gfx_menu_get_selected(const Evas_Object *object);
const Eina_List *gfx_menu_get_items(const Evas_Object *object);
Evas_Object *gfx_menu_get_itemobject(const Elm_Object_Item *item);
void gfx_menu_set_itemselected(Elm_Object_Item *item, Eina_Bool selected);
Eina_Bool gfx_menu_get_itemdisabled(const Elm_Object_Item *item);
void gfx_menu_set_itemicon(Elm_Object_Item *item, const char *icon);
const char *gfx_menu_get_itemicon(const Elm_Object_Item *item);
void gfx_menu_set_itemlabel(Elm_Object_Item *item, const char *label);
const char *gfx_menu_get_itemlabel(const Elm_Object_Item *item);
Eina_Bool gfx_menu_get_itemselected(const Elm_Object_Item *item);
const Eina_List *gfx_menu_get_subitems(const Elm_Object_Item *item);
void gfx_menu_del_item(Elm_Object_Item *item);

/* Menu Functions - End */

/* Parallel Flip Functions - Start */

Evas_Object *gfx_object_add_flip(Evas_Object *parent);
void gfx_flip_go(Evas_Object *object, Elm_Flip_Mode mode);
void gfx_flip_go_to(Evas_Object *object, Eina_Bool front, Elm_Flip_Mode mode);
void gfx_flip_set_interaction(Evas_Object *object, Elm_Flip_Interaction mode);
void gfx_flip_set_swipedirection(Evas_Object *object, Elm_Flip_Direction dir, Eina_Bool enabled);
Eina_Bool gfx_flip_get_swipedirection(Evas_Object *object, Elm_Flip_Direction dir);
void gfx_flip_set_swipehitsize(Evas_Object *object, Elm_Flip_Direction dir, double siz);
double gfx_flip_get_swipehitsize(Evas_Object *object, Elm_Flip_Direction dir);
void gfx_flip_set_perspective(Evas_Object *object, Evas_Coord foc, Evas_Coord x, Evas_Coord y);
Evas_Object *gfx_flip_get_selectedchild(const Evas_Object *object);

/* Parallel Flip Functions - End */

/* Parallel Hover Functions - Start */

Evas_Object *gfx_object_add_hover(Evas_Object *parent);
void gfx_hover_set_target(Evas_Object *object, Evas_Object *target);
Evas_Object *gfx_hover_get_target(const Evas_Object *object);

/* Parallel Hover Functions - End */

/* Parallel Inwin Functions - Start */

Evas_Object *gfx_object_add_inwin(Evas_Object *parent);
void gfx_inwin_set_content(Evas_Object *object, Evas_Object *content);
Evas_Object *gfx_inwin_get_content(const Evas_Object *object);

/* Parallel Inwin Functions - End */

/* Parallel Layout Functions - Start */

Evas_Object *gfx_object_add_layout(Evas_Object *parent);
Eina_Bool gfx_layout_set_file(Evas_Object *object, const char *file, const char *group);
void gfx_layout_get_file(Evas_Object *object, const char **file, const char **group);
Eina_Bool gfx_layout_set_theme(Evas_Object *object, const char *klass, const char *group, const char *style);
void gfx_layout_signal_emit(Evas_Object *object, const char *emission, const char *source);
void gfx_layout_add_signalcallback(Evas_Object *object, const char *emission, const char *source, Edje_Signal_Cb func, const void *data);
void gfx_layout_del_signalcallback(Evas_Object *object, const char *emission, const char *source, Edje_Signal_Cb func);

/* Parallel Layout Functions - End */

/* Parallel Map Functions - Start */

Evas_Object *gfx_object_add_map(Evas_Object *parent);
void gfx_map_set_zoom(Evas_Object *object, int zoom);
int gfx_map_get_zoom(const Evas_Object *object);
Eina_Bool gfx_map_set_source(Evas_Object *object, const char *type, const char *source);
const char *gfx_map_get_source(const Evas_Object *object, const char *type);

/* Parallel Map Functions - End */

/* Parallel Panel Functions - Start */

Evas_Object *gfx_object_add_panel(Evas_Object *parent);
void gfx_panel_set_orient(Evas_Object *object, Elm_Panel_Orient orient);
Elm_Panel_Orient gfx_panel_get_orient(const Evas_Object *object);
void gfx_panel_set_hidden(Evas_Object *object, Eina_Bool hidden);
Eina_Bool gfx_panel_get_hidden(const Evas_Object *object);
void gfx_panel_toggle(Evas_Object *object);
void gfx_panel_set_scrollable(Evas_Object *object, Eina_Bool scrollable);
Eina_Bool gfx_panel_get_scrollable(const Evas_Object *object);

/* Parallel Panel Functions - End */

/* Parallel Panes Functions - Start */

Evas_Object *gfx_object_add_panes(Evas_Object *parent);
void gfx_panes_set_horizontal(Evas_Object *object, Eina_Bool horizontal);
Eina_Bool gfx_panes_get_horizontal(const Evas_Object *object);
void gfx_panes_set_leftsize(Evas_Object *object, double size);
double gfx_panes_get_leftsize(const Evas_Object *object);
void gfx_panes_set_rightsize(Evas_Object *object, double size);
double gfx_panes_get_rightsize(const Evas_Object *object);
void gfx_panes_set_fixed(Evas_Object *object, Eina_Bool fixed);
Eina_Bool gfx_panes_get_fixed(const Evas_Object *object);

/* Parallel Panes Functions - End */

/* Parallel Photocam Functions - Start */

Evas_Object *gfx_object_add_photocam(Evas_Object *parent);
Eina_Error gfx_photocam_set_file(Evas_Object *object, const char *file);
const char *gfx_photocam_get_file(const Evas_Object *object);
void gfx_photocam_set_zoom(Evas_Object *object, double zoom);
double gfx_photocam_get_zoom(const Evas_Object *object);
void gfx_photocam_get_imagesize(const Evas_Object *object, int *w, int *h);

/* Parallel Photocam Functions - End */

#endif
