#include <Elementary.h>
#include <Evas.h>
#include <stdio.h>
#include "grassfx.h"

/* Canvas and Basic Object Management - Start */

Evas *gfx_object_get_evas(const Evas_Object *object)
{
	Evas *ret;

	if (!object)
		return NULL;

	ret = evas_object_evas_get(object);
	return ret;
}

void gfx_object_show(Evas_Object *object)
{
	if (!object)
		return;

	evas_object_show(object);
}

void gfx_object_hide(Evas_Object *object)
{
	if (!object)
		return;

	evas_object_hide(object);
}

void gfx_object_del(Evas_Object *object)
{
	if (!object)
		return;

	evas_object_del(object);
}

void gfx_object_raise(Evas_Object *object)
{
	if (!object)
		return;

	evas_object_raise(object);
}

void gfx_object_lower(Evas_Object *object)
{
	if (!object)
		return;

	evas_object_lower(object);
}

void gfx_object_set_size_hintweight(Evas_Object *object, double x, double y)
{
	if (!object)
		return;

	evas_object_size_hint_weight_set(object, x, y);
}

void gfx_object_set_size_hintalign(Evas_Object *object, double x, double y)
{
	if (!object)
		return;

	evas_object_size_hint_align_set(object, x, y);
}

/* Canvas and Basic Object Management - End */

/* Geometry, Position and Color - Start */

void gfx_object_move(Evas_Object *object, Evas_Coord x, Evas_Coord y)
{
	if (!object)
		return;

	evas_object_move(object, x, y);
}

void gfx_object_resize(Evas_Object *object, Evas_Coord w, Evas_Coord h)
{
	if (!object)
		return;

	evas_object_resize(object, w, h);
}

void gfx_object_get_geometry(Evas_Object *object, Evas_Coord *x, Evas_Coord *y, Evas_Coord *w, Evas_Coord *h)
{
	if (!object)
		return;

	evas_object_geometry_get(object, x, y, w, h);
}

void gfx_object_set_color(Evas_Object *object, int r, int g, int b, int a)
{
	if (!object)
		return;

	evas_object_color_set(object, r, g, b, a);
}

void gfx_object_get_color(const Evas_Object *object, int *r, int *g, int *b, int *a)
{
	if (!object)
		return;

	evas_object_color_get(object, r, g, b, a);
}

void gfx_object_set_minsize(Evas_Object *object, Evas_Coord w, Evas_Coord h)
{
	if (!object)
		return;

	evas_object_size_hint_min_set(object, w, h);
}

void gfx_object_set_maxsize(Evas_Object *object, Evas_Coord w, Evas_Coord h)
{
	if (!object)
		return;

	evas_object_size_hint_max_set(object, w, h);
}

/* Geometry, Position and Color - End */

/* Object Creation / Factory - Start */

Evas_Object *gfx_object_add_rectangle(Evas *canvas)
{
	Evas_Object *object;

	if (!canvas)
		return NULL;

	object = evas_object_rectangle_add(canvas);
	return object;
}

Evas_Object *gfx_object_add_rawimage(Evas *canvas)
{
	Evas_Object *object;

	if (!canvas)
		return NULL;

	object = evas_object_image_add(canvas);
	return object;
}

Evas_Object *gfx_object_add_text(Evas *canvas)
{
	Evas_Object *object;

	if (!canvas)
		return NULL;

	object = evas_object_text_add(canvas);
	return object;
}

Evas_Object *gfx_object_add_textblock(Evas *canvas)
{
	Evas_Object *object;

	if (!canvas)
		return NULL;

	object = evas_object_textblock_add(canvas);
	return object;
}

/* Object Creation / Factory - End */

/* Image Operations - Start */

void gfx_object_set_imagefile(Evas_Object *object, const char *file, const char *key)
{
	if (!object || !file)
		return;

	evas_object_image_file_set(object, file, key);
}

void gfx_object_set_imagefilled(Evas_Object *object, Eina_Bool filled)
{
	if (!object)
		return;

	evas_object_image_filled_set(object, filled);
}

void gfx_object_set_imagesize(Evas_Object *object, int w, int h)
{
	if (!object)
		return;

	evas_object_image_size_set(object, w, h);
}

void gfx_object_get_imagesize(Evas_Object *object, int *w, int *h)
{
	if (!object)
		return;

	evas_object_image_size_get(object, w, h);
}

/* Image Operations - End */

/* Text Operations - Start */

Eina_Bool gfx_object_set_textfont(Evas_Object *object, const char *font, Evas_Font_Size size)
{
	if (!object || !font)
		return EINA_FALSE;

	evas_object_text_font_set(object, font, size);

	return EINA_TRUE;
}

void gfx_object_set_rawtext(Evas_Object *object, const char *text)
{
	if (!object || !text)
		return;

	evas_object_text_text_set(object, text);
}

const char *gfx_object_get_rawtext(const Evas_Object *object)
{
	const char *ret;

	if (!object)
		return NULL;

	ret = evas_object_text_text_get(object);
	return ret;
}

Eina_Bool gfx_object_set_textblockmarkup(Evas_Object *object, const char *text)
{
	if (!object || !text)
		return EINA_FALSE;

	evas_object_textblock_text_markup_set(object, text);
	return EINA_TRUE;
}

/* Text Operations - End */

/* Events and Interaction - Start */

void gfx_object_add_eventcallback(Evas_Object *object, Evas_Callback_Type type, Evas_Object_Event_Cb func, const void *data)
{
	if (!object || !func)
		return;

	evas_object_event_callback_add(object, type, func, data);
}

void gfx_object_add_smartcallback(Evas_Object *object, const char *event, Evas_Smart_Cb func, const void *data)
{
	if (!object || !event || !func)
		return;

	evas_object_smart_callback_add(object, event, func, data);
}

void gfx_object_set_focus(Evas_Object *object, Eina_Bool focus)
{
	if (!object)
		return;

	evas_object_focus_set(object, focus);
}

/* Events and Interaction - End */

/* Cropping / Masking - Start */

void gfx_object_set_clip(Evas_Object *object, Evas_Object *clip)
{
	if (!object || !clip)
		return;

	evas_object_clip_set(object, clip);
}

void gfx_object_unset_clip(Evas_Object *object)
{
	if (!object)
		return;

	evas_object_clip_unset(object);
}

/* Cropping / Masking - End */
