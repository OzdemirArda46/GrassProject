#include <Elementary.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include "grassfx.h"

/* Window Functions - Start */

Evas_Object *gfx_object_new_feature_window(const char *name, const char *title)
{
	Evas_Object *object;

	if (!name || !title)
		return NULL;

	object = elm_win_util_standard_add(name, title);
	return object;
}

Evas_Object *gfx_object_new_standard_window(Evas_Object *parent, const char *name, Elm_Win_Type type)
{
	Evas_Object *object;

	if (!name)
		return NULL;

	object = elm_win_add(parent, name, type);
	return object;
}

int gfx_window_set_title(Evas_Object *object, const char *title)
{
	if (!object || !title)
		return -1;

	elm_win_title_set(object, title);
	return 0;
}

int gfx_window_set_autodel(Evas_Object *object, Eina_Bool autodel)
{
	if (!object)
		return -1;

	elm_win_autodel_set(object, autodel);
	return 0;
}

int gfx_window_set_center(Evas_Object *object, Eina_Bool h, Eina_Bool v)
{
	if (!object)
		return -1;

	elm_win_center(object, h, v);
	return 0;
}

int gfx_window_set_minsize(Evas_Object *object, int w, int h)
{
	if (!object)
		return -1;

	elm_win_size_base_set(object, w, h);
	return 0;
}

int gfx_window_set_fullscreen(Evas_Object *object, Eina_Bool full)
{
	if (!object)
		return -1;

	elm_win_fullscreen_set(object, full);
	return 0;
}

int gfx_window_set_active(Evas_Object *object)
{
	if (!object)
		return -1;

	elm_win_activate(object);
	return 0;
}

int gfx_window_set_iconified(Evas_Object *object, Eina_Bool iconified)
{
	if (!object)
		return -1;

	elm_win_iconified_set(object, iconified);
	return 0;
}

int gfx_window_set_sticky(Evas_Object *object, Eina_Bool sticky)
{
	if (!object)
		return -1;

	elm_win_sticky_set(object, sticky);
	return 0;
}

int gfx_window_proportion_scale(Evas_Object *object, Evas_Object *subobject)
{
	if (!object || !subobject)
		return -1;

	elm_win_resize_object_add(object, subobject);
	return 0;
}

void gfx_window_set_autohide(Evas_Object *object, Eina_Bool autohide)
{
	if (!object)
		return;

	elm_win_autohide_set(object, autohide);
}

void gfx_window_set_borderless(Evas_Object *object, Eina_Bool borderless)
{
	if (!object)
		return;
		
	elm_win_borderless_set(object, borderless);
}

Eina_Bool gfx_window_get_borderless(const Evas_Object *object)
{
	if (!object)
		return EINA_FALSE;
		
	return elm_win_borderless_get(object);
}

void gfx_window_set_shaped(Evas_Object *object, Eina_Bool shaped)
{
	if (!object)
		return;
		
	elm_win_shaped_set(object, shaped);
}

Eina_Bool gfx_window_get_shaped(const Evas_Object *object)
{
	if (!object)
		return EINA_FALSE;
		
	return elm_win_shaped_get(object);
}

void gfx_window_set_alpha(Evas_Object *object, Eina_Bool alpha)
{
	if (!object)
		return;
		
	elm_win_alpha_set(object, alpha);
}

Eina_Bool gfx_window_get_alpha(const Evas_Object *object)
{
	if (!object)
		return EINA_FALSE;
	
	return elm_win_alpha_get(object);
}

/* Window Functions - End */

/* Serial Window Functions - Start */

Evas_Object *gfx_object_create_window(Evas_Object *parent, const char *name, Elm_Win_Type type, const char *title, Evas_Coord x, Evas_Coord y)
{
	Evas_Object *object;

	if (!name || !title)
		return NULL;

	object = elm_win_add(parent, name, type);
	if (!object)
		return NULL;

	elm_win_title_set(object, title);
	elm_win_autodel_set(object, EINA_TRUE);
	evas_object_resize(object, x, y);
	evas_object_show(object);

	return object;
}

/* Serial Window Functions - End */

/* Widget Addition Functions - Start */

Evas_Object *gfx_object_add_button(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_button_add(parent);
	return object;
}

Evas_Object *gfx_object_add_checkbutton(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_check_add(parent);
	return object;
}

Evas_Object *gfx_object_add_radiobutton(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_radio_add(parent);
	return object;
}

Evas_Object *gfx_object_add_entry(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_entry_add(parent);
	return object;
}

Evas_Object *gfx_object_add_slider(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_slider_add(parent);
	return object;
}

Evas_Object *gfx_object_add_spinner(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_spinner_add(parent);
	return object;
}

Evas_Object *gfx_object_add_combobox(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_combobox_add(parent);
	return object;
}

Evas_Object *gfx_object_add_label(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_label_add(parent);
	return object;
}

Evas_Object *gfx_object_add_icon(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_icon_add(parent);
	return object;
}

Evas_Object *gfx_object_add_image(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_image_add(parent);
	return object;
}

Evas_Object *gfx_object_add_progressbar(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_progressbar_add(parent);
	return object;
}

Evas_Object *gfx_object_add_bubble(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_bubble_add(parent);
	return object;
}

Evas_Object *gfx_object_add_clock(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_clock_add(parent);
	return object;
}

Evas_Object *gfx_object_add_calendar(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_calendar_add(parent);
	return object;
}

Evas_Object *gfx_object_add_separator(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_separator_add(parent);
	return object;
}

Evas_Object *gfx_object_add_popup(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_popup_add(parent);
	return object;
}

/* Widget Addition Functions - End */

/* Box Functions - Start */

Evas_Object *gfx_object_add_box(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_box_add(parent);
	return object;
}

void gfx_box_set_horizontal(Evas_Object *object, Eina_Bool horizontal)
{
	if (!object)
		return;

	elm_box_horizontal_set(object, horizontal);
}

Eina_Bool gfx_box_get_horizontal(const Evas_Object *object)
{
	if (!object)
		return EINA_FALSE;

	return elm_box_horizontal_get(object);
}

void gfx_box_pack_start(Evas_Object *object, Evas_Object *child)
{
	if (!object || !child)
		return;

	elm_box_pack_start(object, child);
}

void gfx_box_pack_end(Evas_Object *object, Evas_Object *child)
{
	if (!object || !child)
		return;

	elm_box_pack_end(object, child);
}

void gfx_box_pack_before(Evas_Object *object, Evas_Object *child, Evas_Object *before)
{
	if (!object || !child)
		return;

	elm_box_pack_before(object, child, before);
}

void gfx_box_pack_after(Evas_Object *object, Evas_Object *child, Evas_Object *after)
{
	if (!object || !child)
		return;

	elm_box_pack_after(object, child, after);
}

void gfx_box_unpack(Evas_Object *object, Evas_Object *child)
{
	if (!object || !child)
		return;

	elm_box_unpack(object, child);
}

void gfx_box_unpack_all(Evas_Object *object)
{
	if (!object)
		return;

	elm_box_unpack_all(object);
}

void gfx_box_set_homogeneous(Evas_Object *object, Eina_Bool homogeneous)
{
	if (!object)
		return;

	elm_box_homogeneous_set(object, homogeneous);
}

Eina_Bool gfx_box_get_homogeneous(Evas_Object *object)
{
	if (!object)
		return EINA_FALSE;

	return elm_box_homogeneous_get(object);
}

void gfx_box_set_padding(Evas_Object *object, Evas_Coord horizontal, Evas_Coord vertical)
{
	if (!object)
		return;

	elm_box_padding_set(object, horizontal, vertical);
}

void gfx_box_get_padding(Evas_Object *object, Evas_Coord *horizontal, Evas_Coord *vertical)
{
	if (!object)
		return;

	elm_box_padding_get(object, horizontal, vertical);
}

void gfx_box_set_align(Evas_Object *object, double horizontal, double vertical)
{
	if (!object)
		return;

	elm_box_align_set(object, horizontal, vertical);
}

void gfx_box_get_align(Evas_Object *object, double *horizontal, double *vertical)
{
	if (!object)
		return;

	elm_box_align_get(object, horizontal, vertical);
}

Eina_List *gfx_box_get_children(const Evas_Object *object)
{
	Eina_List *list;

	if (!object)
		return NULL;

	list = elm_box_children_get(object);
	return list;
}

void gfx_box_clear(Evas_Object *object)
{
	if (!object)
		return;
      
	elm_box_clear(object);
}

void gfx_box_set_layout(Evas_Object *object, Evas_Object_Box_Layout func, const void *data, Eina_Free_Cb free_data)
{
	if (!object)
		return;
  
	elm_box_layout_set(object, func, data, free_data);
}

/* Box Functions - End */

/* Grid Functions - Start */

Evas_Object *gfx_object_add_grid(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_grid_add(parent);
	return object;
}

void gfx_grid_set_size(Evas_Object *object, int w, int h)
{
	if (!object)
		return;

	elm_grid_size_set(object, w, h);
}

void gfx_grid_get_size(const Evas_Object *object, int *w, int *h)
{
	if (!object)
		return;

	elm_grid_size_get(object, w, h);
}

void gfx_grid_add_pack(Evas_Object *object, Evas_Object *subobject, int x, int y, int w, int h)
{
	if (!object || !subobject)
		return;

	elm_grid_pack(object, subobject, x, y, w, h);
}

void gfx_grid_unpack(Evas_Object *object, Evas_Object *subobject)
{
	if (!object || !subobject)
		return;

	elm_grid_unpack(object, subobject);
}

void gfx_grid_set_pack(Evas_Object *subobject, Evas_Coord x, Evas_Coord y, Evas_Coord w, Evas_Coord h)
{
	if (!subobject)
		return;

	elm_grid_pack_set(subobject, x, y, w, h);
}

void gfx_grid_get_pack(Evas_Object *subobject, Evas_Coord *x, Evas_Coord *y, Evas_Coord *w, Evas_Coord *h)
{
	if (!subobject)
		return;

	elm_grid_pack_get(subobject, x, y, w, h);
}

Eina_List *gfx_grid_get_children(const Evas_Object *object)
{
	if (!object)
		return NULL;

	return elm_grid_children_get(object);
}

void gfx_grid_clear(Evas_Object *object, Eina_Bool clear)
{
	if (!object)
		return;

	elm_grid_clear(object, clear);
}

/* Grid Functions - End */

/* Table Functions - Start */

Evas_Object *gfx_object_add_table(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_table_add(parent);
	return object;
}

void gfx_table_set_align(Evas_Object *object, double horizontal, double vertical)
{
	if (!object)
		return;

	elm_table_align_set(object, horizontal, vertical);
}

void gfx_table_get_align(const Evas_Object *object, double *horizontal, double *vertical)
{
	if (!object)
		return;

	elm_table_align_get(object, horizontal, vertical);
}

Evas_Object *gfx_table_get_child(const Evas_Object *object, int col, int row)
{
	if (!object)
		return NULL;

	return elm_table_child_get(object, col, row);
}

void gfx_table_clear(Evas_Object *object, Eina_Bool clear)
{
	if (!object)
		return;

	elm_table_clear(object, clear);
}

void gfx_table_set_homogeneous(Evas_Object *object, Eina_Bool homogeneous)
{
	if (!object)
		return;

	elm_table_homogeneous_set(object, homogeneous);
}

Eina_Bool gfx_table_get_homogeneous(const Evas_Object *object)
{
	if (!object)
		return EINA_FALSE;

	return elm_table_homogeneous_get(object);
}

void gfx_table_pack(Evas_Object *object, Evas_Object *subobject, int col, int row, int colspan, int rowspan)
{
	if (!object || !subobject)
		return;

	elm_table_pack(object, subobject, col, row, colspan, rowspan);
}

void gfx_table_set_pack(Evas_Object *subobject, int col, int row, int colspan, int rowspan)
{
	if (!subobject)
		return;

	elm_table_pack_set(subobject, col, row, colspan, rowspan);
}

void gfx_table_get_pack(Evas_Object *subobject, int *col, int *row, int *colspan, int *rowspan)
{
	if (!subobject)
		return;

	elm_table_pack_get(subobject, col, row, colspan, rowspan);
}

void gfx_table_set_padding(Evas_Object *object, Evas_Coord horizontal, Evas_Coord vertical)
{
	if (!object)
		return;

	elm_table_padding_set(object, horizontal, vertical);
}

void gfx_table_get_padding(Evas_Object *object, Evas_Coord *horizontal, Evas_Coord *vertical)
{
	if (!object)
		return;

	elm_table_padding_get(object, horizontal, vertical);
}

void gfx_table_unpack(Evas_Object *object, Evas_Object *subobject)
{
	if (!object || !subobject)
		return;

	elm_table_unpack(object, subobject);
}

/* Table Functions - End */

/* Scroller Functions - Start */

Evas_Object *gfx_object_add_scroller(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_scroller_add(parent);
	return object;
}

void gfx_scroller_set_policy(Evas_Object *object, Elm_Scroller_Policy policy_h, Elm_Scroller_Policy policy_v)
{
	if (!object)
		return;

	elm_scroller_policy_set(object, policy_h, policy_v);
}

void gfx_scroller_get_policy(const Evas_Object *object, Elm_Scroller_Policy *policy_h, Elm_Scroller_Policy *policy_v)
{
	if (!object)
		return;

	elm_scroller_policy_get(object, policy_h, policy_v);
}

void gfx_scroller_set_region(Evas_Object *object, Evas_Coord x, Evas_Coord y, Evas_Coord w, Evas_Coord h)
{
	if (!object)
		return;

	elm_scroller_region_show(object, x, y, w, h);
}

void gfx_scroller_get_region(const Evas_Object *object, Evas_Coord *x, Evas_Coord *y, Evas_Coord *w, Evas_Coord *h)
{
	if (!object)
		return;

	elm_scroller_region_get(object, x, y, w, h);
}

void gfx_scroller_get_position(const Evas_Object *object, Evas_Coord *x, Evas_Coord *y)
{
	if (!object)
		return;

	elm_scroller_region_get(object, x, y, NULL, NULL);
}

void gfx_scroller_set_pagesize(Evas_Object *object, Evas_Coord w, Evas_Coord h)
{
	if (!object)
		return;

	elm_scroller_page_size_set(object, w, h);
}

void gfx_scroller_get_pagesize(const Evas_Object *object, Evas_Coord *w, Evas_Coord *h)
{
	if (!object)
		return;

	elm_scroller_page_size_get(object, w, h);
}

void gfx_scroller_get_currentpage(const Evas_Object *object, int *hp, int *vp)
{
	if (!object)
		return;

	elm_scroller_current_page_get(object, hp, vp);
}

void gfx_scroller_show_page(Evas_Object *object, int hp, int vp)
{
	if (!object)
		return;

	elm_scroller_page_show(object, hp, vp);
}

void gfx_scroller_set_bounce(Evas_Object *object, Eina_Bool h_bounce, Eina_Bool v_bounce)
{
	if (!object)
		return;

	elm_scroller_bounce_set(object, h_bounce, v_bounce);
}

void gfx_scroller_get_bounce(const Evas_Object *object, Eina_Bool *h_bounce, Eina_Bool *v_bounce)
{
	if (!object)
		return;

	elm_scroller_bounce_get(object, h_bounce, v_bounce);
}

/* Scroller Functions - End */

/* Frame Functions - Start */

Evas_Object *gfx_object_add_frame(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_frame_add(parent);
	return object;
}

void gfx_frame_set_autocollapse(Evas_Object *object, Eina_Bool autocollapse)
{
	if (!object)
		return;

	elm_frame_autocollapse_set(object, autocollapse);
}

Eina_Bool gfx_frame_get_autocollapse(const Evas_Object *object)
{
	if (!object)
		return EINA_FALSE;

	return elm_frame_autocollapse_get(object);
}

void gfx_frame_set_collapse(Evas_Object *object, Eina_Bool collapse)
{
	if (!object)
		return;

	elm_frame_collapse_set(object, collapse);
}

Eina_Bool gfx_frame_get_collapse(const Evas_Object *object)
{
	if (!object)
		return EINA_FALSE;

	return elm_frame_collapse_get(object);
}

/* Frame Functions - End */

/* Object Management Functions - Start */

void gfx_object_set_text(Evas_Object *object, const char *text)
{
	if (!object || !text)
		return;

	elm_object_text_set(object, text);
}

const char *gfx_object_get_text(const Evas_Object *object)
{
	if (!object)
		return NULL;

	return elm_object_text_get(object);
}

void gfx_object_set_content(Evas_Object *object, Evas_Object *content)
{
	if (!object)
		return;

	elm_object_content_set(object, content);
}

Evas_Object *gfx_object_get_content(const Evas_Object *object)
{
	if (!object)
		return NULL;

	return elm_object_content_get(object);
}

Eina_Bool gfx_image_set_file(Evas_Object *object, const char *file, const char *group)
{
	if (!object || !file)
		return EINA_FALSE;

	return elm_image_file_set(object, file, group);
}

Eina_Bool gfx_icon_set_standard(Evas_Object *object, const char *name)
{
	if (!object || !name)
		return EINA_FALSE;

	return elm_icon_standard_set(object, name);
}

void gfx_object_set_parttext(Evas_Object *object, const char *part, const char *text)
{
	if (!object || !part || !text)
		return;

	elm_object_part_text_set(object, part, text);
}

void gfx_object_set_partcontent(Evas_Object *object, const char *part, Evas_Object *content)
{
	if (!object || !part)
		return;

	elm_object_part_content_set(object, part, content);
}

Eina_Bool gfx_set_policy(unsigned int policy, int value)
{
	return elm_policy_set(policy, value);
}

void gfx_object_set_disabled(Evas_Object *object, Eina_Bool disabled)
{
	if (!object)
		return;

	elm_object_disabled_set(object, disabled);
}

/* Object Management Functions - End */

/* Entry and State Functions - Start */

void gfx_entry_set_text(Evas_Object *object, const char *text)
{
	if (!object || !text)
		return;

	elm_entry_entry_set(object, text);
}

const char *gfx_entry_get_text(const Evas_Object *object)
{
	if (!object)
		return NULL;

	return elm_entry_entry_get(object);
}

void gfx_entry_set_singleline(Evas_Object *object, Eina_Bool single_line)
{
	if (!object)
		return;

	elm_entry_single_line_set(object, single_line);
}

void gfx_entry_set_password(Evas_Object *object, Eina_Bool password)
{
	if (!object)
		return;

	elm_entry_password_set(object, password);
}

void gfx_check_set_state(Evas_Object *object, Eina_Bool checked)
{
	if (!object)
		return;

	elm_check_state_set(object, checked);
}

Eina_Bool gfx_check_get_state(const Evas_Object *object)
{
	if (!object)
		return EINA_FALSE;

	return elm_check_state_get(object);
}

void gfx_radio_set_statevalue(Evas_Object *object, int value)
{
	if (!object)
		return;

	elm_radio_state_value_set(object, value);
}

void gfx_radio_set_value(Evas_Object *object, int value)
{
	if (!object)
		return;

	elm_radio_value_set(object, value);
}

int gfx_radio_get_value(const Evas_Object *object)
{
	if (!object)
		return -1;

	return elm_radio_value_get(object);
}

void gfx_radio_add_group(Evas_Object *object, Evas_Object *group)
{
	if (!object || !group)
		return;

	elm_radio_group_add(object, group);
}

void gfx_radio_set_pointervalue(Evas_Object *object, int *valuep)
{
	if (!object || !valuep)
		return;

	elm_radio_value_pointer_set(object, valuep);
}

void gfx_slider_set_minmax(Evas_Object *object, double min, double max)
{
	if (!object)
		return;

	elm_slider_min_max_set(object, min, max);
}

void gfx_slider_set_unitformat(Evas_Object *object, const char *format)
{
	if (!object)
		return;

	elm_slider_unit_format_set(object, format);
}

void gfx_slider_set_value(Evas_Object *object, double value)
{
	if (!object)
		return;

	elm_slider_value_set(object, value);
}

double gfx_slider_get_value(const Evas_Object *object)
{
	if (!object)
		return 0.0;

	return elm_slider_value_get(object);
}

/* Entry and State Functions - End */

/* Genlist Functions - Start */

Elm_Object_Item *gfx_genlist_add_item(Evas_Object *object, const Elm_Genlist_Item_Class *itemclass, const void *data, Elm_Object_Item *parent, Elm_Genlist_Item_Type flags, Evas_Smart_Cb function, const void *function_data)
{
	if (!object || !itemclass)
		return NULL;

	return elm_genlist_item_append(object, itemclass, data, parent, flags, function, function_data);
}

void gfx_genlist_clear(Evas_Object *object)
{
	if (!object)
		return;

	elm_genlist_clear(object);
}

Elm_Genlist_Item_Class *gfx_genlist_add_itemclass(void)
{
	return elm_genlist_item_class_new();
}

void gfx_genlist_free_itemclass(Elm_Genlist_Item_Class *itemclass)
{
	if (!itemclass)
		return;

	elm_genlist_item_class_free(itemclass);
}

/* Genlist Functions - End */

/* Background Functions - Start */

Evas_Object *gfx_object_add_background(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_bg_add(parent);
	return object;
}

Eina_Bool gfx_background_set_file(Evas_Object *object, const char *file, const char *group)
{
	if (!object || !file)
		return EINA_FALSE;

	return elm_bg_file_set(object, file, group);
}

void gfx_background_get_file(const Evas_Object *object, const char **file, const char **group)
{
	if (!object)
		return;

	elm_bg_file_get(object, file, group);
}

void gfx_background_set_option(Evas_Object *object, Elm_Bg_Option option)
{
	if (!object)
		return;

	elm_bg_option_set(object, option);
}

Elm_Bg_Option gfx_background_get_option(const Evas_Object *object)
{
	if (!object)
		return (Elm_Bg_Option)0;

	return elm_bg_option_get(object);
}

void gfx_background_set_color(Evas_Object *object, int r, int g, int b)
{
	if (!object)
		return;

	elm_bg_color_set(object, r, g, b);
}

void gfx_background_get_color(const Evas_Object *object, int *r, int *g, int *b)
{
	if (!object)
		return;

	elm_bg_color_get(object, r, g, b);
}

void gfx_background_set_loadsize(Evas_Object *object, int w, int h)
{
	if (!object)
		return;

	elm_bg_load_size_set(object, w, h);
}

/* Background Functions - End */

/* Menu Functions - Start */

Evas_Object *gfx_object_add_menu(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;
	
	object = elm_menu_add(parent);
	return object;
}

Elm_Object_Item *gfx_menu_add_item(Evas_Object *object, Elm_Object_Item *parent, const char *icon, const char *label, Evas_Smart_Cb func, const void *data)
{
	if (!object)
		return NULL;

	return elm_menu_item_add(object, parent, icon, label, func, data);
}

Elm_Object_Item *gfx_menu_add_separator(Evas_Object *object, Elm_Object_Item *parent)
{
	if (!object)
		return NULL;

	return elm_menu_item_separator_add(object, parent);
}

Elm_Object_Item *gfx_menu_add_submenu(Evas_Object *object, Elm_Object_Item *parent, const char *label)
{
	if (!object)
		return NULL;

	return elm_menu_item_add(object, parent, NULL, label, NULL, NULL);
}

void gfx_menu_move(Evas_Object *object, Evas_Coord x, Evas_Coord y)
{
	if (!object)
		return;
		
	elm_menu_move(object, x, y);
}

void gfx_menu_close(Evas_Object *object)
{
	if (!object)
		return;
  
	elm_menu_close(object);
}

Elm_Object_Item *gfx_menu_get_selected(const Evas_Object *object)
{
	if (!object)
		return NULL;

	return elm_menu_selected_item_get(object);
}

const Eina_List *gfx_menu_get_items(const Evas_Object *object)
{
	if (!object)
		return NULL;

	return elm_menu_items_get(object);
}

Evas_Object *gfx_menu_get_itemobject(const Elm_Object_Item *item)
{
	Evas_Object *object;

	if (!item)
		return NULL;

	object = elm_object_item_widget_get(item);
	return object;
}

void gfx_menu_set_itemselected(Elm_Object_Item *item, Eina_Bool selected)
{
	if (!item)
		return;

	elm_menu_item_selected_set(item, selected);
}

Eina_Bool gfx_menu_get_itemdisabled(const Elm_Object_Item *item)
{
	if (!item)
		return EINA_FALSE;

	return elm_object_item_disabled_get(item);
}

void gfx_menu_set_itemicon(Elm_Object_Item *item, const char *icon)
{
	if (!item)
		return;

	elm_menu_item_icon_name_set(item, icon);
}

const char *gfx_menu_get_itemicon(const Elm_Object_Item *item)
{
	if (!item)
		return NULL;

	return elm_menu_item_icon_name_get(item);
}

void gfx_menu_set_itemlabel(Elm_Object_Item *item, const char *label)
{
	if (!item)
		return;
		
	elm_object_item_text_set(item, label);
}

const char *gfx_menu_get_itemlabel(const Elm_Object_Item *item)
{
	if (!item)
		return NULL;

	return elm_object_item_text_get(item);
}

Eina_Bool gfx_menu_get_itemselected(const Elm_Object_Item *item)
{
	if (!item)
		return EINA_FALSE;

	return elm_menu_item_selected_get(item);
}

const Eina_List *gfx_menu_get_subitems(const Elm_Object_Item *item)
{
	if (!item)
		return NULL;

	return elm_menu_item_subitems_get(item);
}

void gfx_menu_del_item(Elm_Object_Item *item)
{
	if (!item)
		return;

	elm_object_item_del(item);
}

/* Menu Functions - End */

/* Parallel Flip Functions - Start */

Evas_Object *gfx_object_add_flip(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_flip_add(parent);
	return object;
}

void gfx_flip_go(Evas_Object *object, Elm_Flip_Mode mode)
{
	if (!object)
		return;

	elm_flip_go(object, mode);
}

void gfx_flip_go_to(Evas_Object *object, Eina_Bool front, Elm_Flip_Mode mode)
{
	if (!object)
		return;

	elm_flip_go_to(object, front, mode);
}

void gfx_flip_set_interaction(Evas_Object *object, Elm_Flip_Interaction mode)
{
	if (!object)
		return;

	elm_flip_interaction_set(object, mode);
}

void gfx_flip_set_swipedirection(Evas_Object *object, Elm_Flip_Direction dir, Eina_Bool enabled)
{
	if (!object)
		return;

	elm_flip_interaction_direction_enabled_set(object, dir, enabled);
}

Eina_Bool gfx_flip_get_swipedirection(Evas_Object *object, Elm_Flip_Direction dir)
{
	if (!object)
		return EINA_FALSE;

	return elm_flip_interaction_direction_enabled_get(object, dir);
}

void gfx_flip_set_swipehitsize(Evas_Object *object, Elm_Flip_Direction dir, double siz)
{
	if (!object)
		return;

	elm_flip_interaction_direction_hitsize_set(object, dir, siz);
}

double gfx_flip_get_swipehitsize(Evas_Object *object, Elm_Flip_Direction dir)
{
	if (!object)
		return 0.0;

	return elm_flip_interaction_direction_hitsize_get(object, dir);
}

void gfx_flip_set_perspective(Evas_Object *object, Evas_Coord foc, Evas_Coord x, Evas_Coord y)
{
	if (!object)
		return;

	elm_flip_perspective_set(object, foc, x, y);
}

Evas_Object *gfx_flip_get_selectedchild(const Evas_Object *object)
{
	if (!object)
		return NULL;

	return elm_object_part_content_get(object, "front");
}

/* Parallel Flip Functions - End */

/* Parallel Hover Functions - Start */

Evas_Object *gfx_object_add_hover(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_hover_add(parent);
	return object;
}

void gfx_hover_set_target(Evas_Object *object, Evas_Object *target)
{
	if (!object || !target)
		return;

	elm_hover_target_set(object, target);
}

Evas_Object *gfx_hover_get_target(const Evas_Object *object)
{
	if (!object)
		return NULL;

	return elm_hover_target_get(object);
}

/* Parallel Hover Functions - End */

/* Parallel Inwin Functions - Start */

Evas_Object *gfx_object_add_inwin(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_win_inwin_add(parent);
	return object;
}

void gfx_inwin_set_content(Evas_Object *object, Evas_Object *content)
{
	if (!object || !content)
		return;

	elm_win_inwin_content_set(object, content);
}

Evas_Object *gfx_inwin_get_content(const Evas_Object *object)
{
	if (!object)
		return NULL;

	return elm_win_inwin_content_get(object);
}

/* Parallel Inwin Functions - End */

/* Parallel Layout Functions - Start */

Evas_Object *gfx_object_add_layout(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_layout_add(parent);
	return object;
}

Eina_Bool gfx_layout_set_file(Evas_Object *object, const char *file, const char *group)
{
	if (!object || !file || !group)
		return EINA_FALSE;

	return elm_layout_file_set(object, file, group);
}

void gfx_layout_get_file(Evas_Object *object, const char **file, const char **group)
{
	if (!object)
		return;

	elm_layout_file_get(object, file, group);
}

Eina_Bool gfx_layout_set_theme(Evas_Object *object, const char *klass, const char *group, const char *style)
{
	if (!object)
		return EINA_FALSE;

	return elm_layout_theme_set(object, klass, group, style);
}

void gfx_layout_signal_emit(Evas_Object *object, const char *emission, const char *source)
{
	if (!object || !emission || !source)
		return;

	elm_layout_signal_emit(object, emission, source);
}

void gfx_layout_add_signalcallback(Evas_Object *object, const char *emission, const char *source, Edje_Signal_Cb func, const void *data)
{
	if (!object || !emission || !source || !func)
		return;

	elm_layout_signal_callback_add(object, emission, source, func, (void *)data);
}

void gfx_layout_del_signalcallback(Evas_Object *object, const char *emission, const char *source, Edje_Signal_Cb func)
{
	if (!object || !emission || !source || !func)
		return;

	elm_layout_signal_callback_del(object, emission, source, func);
}

/* Parallel Layout Functions - End */

/* Parallel Map Functions - Start */

Evas_Object *gfx_object_add_map(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_map_add(parent);
	return object;
}

void gfx_map_set_zoom(Evas_Object *object, int zoom)
{
	if (!object)
		return;

	elm_map_zoom_set(object, zoom);
}

int gfx_map_get_zoom(const Evas_Object *object)
{
	if (!object)
		return 0;

	return elm_map_zoom_get(object);
}

Eina_Bool gfx_map_set_source(Evas_Object *object, const char *type, const char *source)
{
	Elm_Map_Source_Type map_type;
	
	if (!object || !type || !source)
		return EINA_FALSE;
	
	if (strcmp(type, "tile") == 0)
			map_type = ELM_MAP_SOURCE_TYPE_TILE;
	else if (strcmp(type, "route") == 0)
			map_type = ELM_MAP_SOURCE_TYPE_ROUTE;
	else if (strcmp(type, "name") == 0)
			map_type = ELM_MAP_SOURCE_TYPE_NAME;
	else
			return EINA_FALSE;

	elm_map_source_set(object, map_type, source);
	return EINA_TRUE;
}

const char *gfx_map_get_source(const Evas_Object *object, const char *type)
{
	Elm_Map_Source_Type map_type;
	
	if (!object || !type)
		return NULL;
		
	if (strcmp(type, "tile") == 0)
			map_type = ELM_MAP_SOURCE_TYPE_TILE;
	else if (strcmp(type, "route") == 0)
			map_type = ELM_MAP_SOURCE_TYPE_ROUTE;
	else if (strcmp(type, "name") == 0)
			map_type = ELM_MAP_SOURCE_TYPE_NAME;
	else
			return NULL;

	return elm_map_source_get(object, map_type);
}

/* Parallel Map Functions - End */

/* Parallel Panel Functions - Start */

Evas_Object *gfx_object_add_panel(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_panel_add(parent);
	return object;
}

void gfx_panel_set_orient(Evas_Object *object, Elm_Panel_Orient orient)
{
	if (!object)
		return;

	elm_panel_orient_set(object, orient);
}

Elm_Panel_Orient gfx_panel_get_orient(const Evas_Object *object)
{
	if (!object)
		return ELM_PANEL_ORIENT_TOP;

	return elm_panel_orient_get(object);
}

void gfx_panel_set_hidden(Evas_Object *object, Eina_Bool hidden)
{
	if (!object)
		return;

	elm_panel_hidden_set(object, hidden);
}

Eina_Bool gfx_panel_get_hidden(const Evas_Object *object)
{
	if (!object)
		return EINA_FALSE;

	return elm_panel_hidden_get(object);
}

void gfx_panel_toggle(Evas_Object *object)
{
	if (!object)
		return;

	elm_panel_toggle(object);
}

void gfx_panel_set_scrollable(Evas_Object *object, Eina_Bool scrollable)
{
	if (!object)
		return;

	elm_panel_scrollable_set(object, scrollable);
}

Eina_Bool gfx_panel_get_scrollable(const Evas_Object *object)
{
	if (!object)
		return EINA_FALSE;

	return elm_panel_scrollable_get(object);
}

/* Parallel Panel Functions - End */

/* Parallel Panes Functions - Start */

Evas_Object *gfx_object_add_panes(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_panes_add(parent);
	return object;
}

void gfx_panes_set_horizontal(Evas_Object *object, Eina_Bool horizontal)
{
	if (!object)
		return;

	elm_panes_horizontal_set(object, horizontal);
}

Eina_Bool gfx_panes_get_horizontal(const Evas_Object *object)
{
	if (!object)
		return EINA_FALSE;

	return elm_panes_horizontal_get(object);
}

void gfx_panes_set_leftsize(Evas_Object *object, double size)
{
	if (!object)
		return;

	elm_panes_content_left_size_set(object, size);
}

double gfx_panes_get_leftsize(const Evas_Object *object)
{
	if (!object)
		return 0.0;

	return elm_panes_content_left_size_get(object);
}

void gfx_panes_set_rightsize(Evas_Object *object, double size)
{
	if (!object)
		return;

	elm_panes_content_right_size_set(object, size);
}

double gfx_panes_get_rightsize(const Evas_Object *object)
{
	if (!object)
		return 0.0;

	return elm_panes_content_right_size_get(object);
}

void gfx_panes_set_fixed(Evas_Object *object, Eina_Bool fixed)
{
	if (!object)
		return;

	elm_panes_fixed_set(object, fixed);
}

Eina_Bool gfx_panes_get_fixed(const Evas_Object *object)
{
	if (!object)
		return EINA_FALSE;

	return elm_panes_fixed_get(object);
}

/* Parallel Panes Functions - End */

/* Parallel Photocam Functions - Start */

Evas_Object *gfx_object_add_photocam(Evas_Object *parent)
{
	Evas_Object *object;

	if (!parent)
		return NULL;

	object = elm_photocam_add(parent);
	return object;
}

Eina_Error gfx_photocam_set_file(Evas_Object *object, const char *file)
{
	if (!object || !file)
		return EINVAL;

	return elm_photocam_file_set(object, file);
}

const char *gfx_photocam_get_file(const Evas_Object *object)
{
	if (!object)
		return NULL;

	return elm_photocam_file_get(object);
}

void gfx_photocam_set_zoom(Evas_Object *object, double zoom)
{
	if (!object)
		return;

	elm_photocam_zoom_set(object, zoom);
}

double gfx_photocam_get_zoom(const Evas_Object *object)
{
	if (!object)
		return 0.0;

	return elm_photocam_zoom_get(object);
}

void gfx_photocam_get_imagesize(const Evas_Object *object, int *w, int *h)
{
	if (!object)
		return;

	elm_photocam_image_size_get(object, w, h);
}

/* Parallel Photocam Functions - End */
