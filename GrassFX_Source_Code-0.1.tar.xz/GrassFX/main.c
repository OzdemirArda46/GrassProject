#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gfx.h"

int
main(int argc, char **argv)
{
	if (!gfx_init(argc, argv))
	{
		fprintf(stderr, "GrassFX initialization failed!\n");
		return 1;
	}

	Evas_Object *win = gfx_object_add_feature_window("grassfx_showcase", "GrassFX Widget Showcase Panel");
	if (!win)
	{
		fprintf(stderr, "Window creation failed!\n");
		gfx_shutdown();
		return 1;
	}

	gfx_window_set_autodel(win, EINA_TRUE);
	gfx_object_resize(win, 600, 700);

	Evas_Object *scroller = gfx_object_add_scroller(win);
	gfx_scroller_set_policy(scroller, ELM_SCROLLER_POLICY_OFF, ELM_SCROLLER_POLICY_AUTO);
	gfx_object_set_size_hintweight(scroller, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	gfx_object_set_size_hintalign(scroller, EVAS_HINT_FILL, EVAS_HINT_FILL);
	gfx_object_show(scroller);

	elm_win_resize_object_add(win, scroller);

	Evas_Object *box = gfx_object_add_box(scroller);
	gfx_box_set_horizontal(box, EINA_FALSE);
	gfx_object_set_size_hintweight(box, EVAS_HINT_EXPAND, 0.0);
	gfx_object_set_size_hintalign(box, EVAS_HINT_FILL, 0.0);
	gfx_object_set_content(scroller, box);
	gfx_object_show(box);

	Evas_Object *label = gfx_object_add_label(box);
	gfx_object_set_text(label, "--- GrassFX Widget Showcase ---");
	gfx_object_set_size_hintweight(label, EVAS_HINT_EXPAND, 0.0);
	gfx_object_set_size_hintalign(label, 0.5, 0.5);
	gfx_box_pack_end(box, label);
	gfx_object_show(label);

	Evas_Object *sep1 = gfx_object_add_separator(box);
	gfx_object_set_size_hintweight(sep1, EVAS_HINT_EXPAND, 0.0);
	gfx_object_set_size_hintalign(sep1, EVAS_HINT_FILL, 0.5);
	gfx_box_pack_end(box, sep1);
	gfx_object_show(sep1);

	Evas_Object *btn = gfx_object_add_button(box);
	gfx_object_set_text(btn, "Sample Button");
	gfx_object_set_size_hintweight(btn, EVAS_HINT_EXPAND, 0.0);
	gfx_object_set_size_hintalign(btn, EVAS_HINT_FILL, 0.5);
	gfx_box_pack_end(box, btn);
	gfx_object_show(btn);

	Evas_Object *chk = gfx_object_add_checkbutton(box);
	gfx_object_set_text(chk, "Sample Checkbox");
	gfx_object_set_size_hintweight(chk, EVAS_HINT_EXPAND, 0.0);
	gfx_object_set_size_hintalign(chk, EVAS_HINT_FILL, 0.5);
	gfx_box_pack_end(box, chk);
	gfx_object_show(chk);

	Evas_Object *entry = gfx_object_add_entry(box);
	gfx_entry_set_text(entry, "Type here...");
	gfx_object_set_size_hintweight(entry, EVAS_HINT_EXPAND, 0.0);
	gfx_object_set_size_hintalign(entry, EVAS_HINT_FILL, 0.5);
	gfx_box_pack_end(box, entry);
	gfx_object_show(entry);

	Evas_Object *slider = gfx_object_add_slider(box);
	gfx_object_set_text(slider, "Level");
	gfx_slider_set_minmax(slider, 0.0, 100.0);
	gfx_slider_set_value(slider, 25.0);
	gfx_object_set_size_hintweight(slider, EVAS_HINT_EXPAND, 0.0);
	gfx_object_set_size_hintalign(slider, EVAS_HINT_FILL, 0.5);
	gfx_box_pack_end(box, slider);
	gfx_object_show(slider);

	Evas_Object *spinner = gfx_object_add_spinner(box);
	gfx_object_set_size_hintweight(spinner, EVAS_HINT_EXPAND, 0.0);
	gfx_object_set_size_hintalign(spinner, EVAS_HINT_FILL, 0.5);
	gfx_box_pack_end(box, spinner);
	gfx_object_show(spinner);

	Evas_Object *prog = gfx_object_add_progressbar(box);
	gfx_object_set_text(prog, "Loading...");
	gfx_object_set_size_hintweight(prog, EVAS_HINT_EXPAND, 0.0);
	gfx_object_set_size_hintalign(prog, EVAS_HINT_FILL, 0.5);
	gfx_box_pack_end(box, prog);
	gfx_object_show(prog);

	Evas_Object *frame = gfx_object_add_frame(box);
	gfx_object_set_text(frame, "Sample Frame");
	gfx_object_set_size_hintweight(frame, EVAS_HINT_EXPAND, 0.0);
	gfx_object_set_size_hintalign(frame, EVAS_HINT_FILL, 0.5);
	gfx_box_pack_end(box, frame);
	gfx_object_show(frame);

	Evas_Object *clock = gfx_object_add_clock(box);
	gfx_object_set_size_hintweight(clock, EVAS_HINT_EXPAND, 0.0);
	gfx_object_set_size_hintalign(clock, EVAS_HINT_FILL, 0.5);
	gfx_box_pack_end(box, clock);
	gfx_object_show(clock);

	Evas_Object *cal = gfx_object_add_calendar(box);
	gfx_object_set_size_hintweight(cal, EVAS_HINT_EXPAND, 0.0);
	gfx_object_set_size_hintalign(cal, EVAS_HINT_FILL, 0.5);
	gfx_box_pack_end(box, cal);
	gfx_object_show(cal);

	gfx_object_show(win);

	gfx_run();

	gfx_shutdown();

	return 0;
}
