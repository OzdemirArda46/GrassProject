#include <Elementary.h>
#include <Ecore.h>
#include <stdio.h>
#include "gfx.h"

/*----------GRASSFX_ECORE_START----------*/

/* Initialization and Shutdown Functions */

int
gfx_ecore_init(void)
{
	return ecore_init();
}

int
gfx_ecore_shutdown(void)
{
	return ecore_shutdown();
}

/* Main Loop Functions */

void
gfx_start_mainloop(void)
{
	ecore_main_loop_begin();
}

void
gfx_quit_mainloop(void)
{
	ecore_main_loop_quit();
}

double
gfx_get_looptime(void)
{
	return ecore_loop_time_get();
}

/* Timer Functions */

Ecore_Timer *
gfx_add_timer(double in_seconds, Ecore_Task_Cb func, const void *data)
{
	if (!func)
		return NULL;

	return ecore_timer_add(in_seconds, func, data);
}

void
gfx_del_timer(Ecore_Timer *timer)
{
	if (!timer)
		return;

	ecore_timer_del(timer);
}

void
gfx_timer_set_interval(Ecore_Timer *timer, double in_seconds)
{
	if (!timer)
		return;

	ecore_timer_interval_set(timer, in_seconds);
}

double
gfx_timer_get_interval(const Ecore_Timer *timer)
{
	if (!timer)
		return 0.0;

	return ecore_timer_interval_get(timer);
}

void
gfx_timer_delay(Ecore_Timer *timer, double add)
{
	if (!timer)
		return;

	ecore_timer_delay(timer, add);
}

void
gfx_timer_freeze(Ecore_Timer *timer)
{
	if (!timer)
		return;

	ecore_timer_freeze(timer);
}

void
gfx_timer_thaw(Ecore_Timer *timer)
{
	if (!timer)
		return;

	ecore_timer_thaw(timer);
}

/* Idler Functions */

Ecore_Idler *
gfx_add_idler(Ecore_Task_Cb func, const void *data)
{
	if (!func)
		return NULL;

	return ecore_idler_add(func, data);
}

void *
gfx_del_idler(Ecore_Idler *idler)
{
	if (!idler)
		return NULL;

	return ecore_idler_del(idler);
}

/* Poller Functions */

Ecore_Poller *
gfx_add_poller(Ecore_Poller_Type type, int interval, Ecore_Task_Cb func, const void *data)
{
	if (!func)
		return NULL;

	return ecore_poller_add(type, interval, func, data);
}

void *
gfx_del_poller(Ecore_Poller *poller)
{
	if (!poller)
		return NULL;

	return ecore_poller_del(poller);
}

/* Thread Functions */

Ecore_Thread *
gfx_run_thread(Ecore_Thread_Cb func_blocking, Ecore_Thread_Cb func_end, Ecore_Thread_Cb func_cancel, const void *data)
{
	if (!func_blocking)
		return NULL;

	return ecore_thread_run(func_blocking, func_end, func_cancel, data);
}

Ecore_Thread *
gfx_thread_run_feedback(Ecore_Thread_Cb func_heavy, Ecore_Thread_Notify_Cb func_notify, Ecore_Thread_Cb func_end, Ecore_Thread_Cb func_cancel, const void *data, Eina_Bool try_no_queue)
{
	if (!func_heavy)
		return NULL;

	return ecore_thread_feedback_run(func_heavy, func_notify, func_end, func_cancel, data, try_no_queue);
}

Eina_Bool
gfx_thread_cancel(Ecore_Thread *th)
{
	if (!th)
		return EINA_FALSE;

	return ecore_thread_cancel(th);
}

void
gfx_thread_add_localdata(Ecore_Thread *th, const char *key, void *value, Eina_Free_Cb cb, Eina_Bool direct)
{
	if (!th || !key)
		return;

	ecore_thread_local_data_add(th, key, value, cb, direct);
}

/* Process Execution Functions */

Ecore_Exe *
gfx_execute_run(const char *exe_command, const void *data)
{
	if (!exe_command)
		return NULL;

	return ecore_exe_run(exe_command, data);
}

Ecore_Exe *
gfx_execute_run_cb(const char *exe_command, Ecore_Exe_Cb func, const void *data)
{
	if (!exe_command || !func)
		return NULL;

	Ecore_Exe *exe = ecore_exe_run(exe_command, (void *)data);
	if (exe && func)
	{
		(void)func;
	}
	return exe;
}

void
gfx_execute_terminate(Ecore_Exe *exe)
{
	if (!exe)
		return;

	ecore_exe_terminate(exe);
}

void
gfx_execute_kill(Ecore_Exe *exe)
{
	if (!exe)
		return;

	ecore_exe_kill(exe);
}

pid_t
gfx_execute_get_pid(const Ecore_Exe *exe)
{
	if (!exe)
		return -1;

	return ecore_exe_pid_get(exe);
}

void
gfx_execute_free(Ecore_Exe *exe)
{
	if (!exe)
		return;

	ecore_exe_free(exe);
}

/* File Descriptor Handler Functions */

Ecore_Fd_Handler *
gfx_add_fdhandler(int fd, Ecore_Fd_Handler_Flags flags, Ecore_Fd_Cb func, const void *data, Ecore_Fd_Cb bufd_func, const void *bufd_data)
{
	if (fd < 0 || !func)
		return NULL;

	return ecore_main_fd_handler_add(fd, flags, func, data, bufd_func, bufd_data);
}

void *
gfx_del_fdhandler(Ecore_Fd_Handler *fd_handler)
{
	if (!fd_handler)
		return NULL;

	return ecore_main_fd_handler_del(fd_handler);
}

/* Event Handler Functions */

Ecore_Event_Handler *
gfx_add_eventhandler(int type, Ecore_Event_Handler_Cb func, const void *data)
{
	if (!func)
		return NULL;

	return ecore_event_handler_add(type, func, data);
}

/*----------GRASSFX_ECORE_END----------*/
